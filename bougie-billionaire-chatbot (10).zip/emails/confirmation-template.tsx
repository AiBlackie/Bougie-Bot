// This is a template for the confirmation email that would be sent
// In a production environment, this would be used with an email service like SendGrid, Mailgun, etc.

export function generateConfirmationEmail(name: string, email: string, tier: string) {
  const tierName = tier === "basic" ? "Language Plus" : tier === "premium" ? "Global Luxury" : "Free"

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Subscription Upgrade Request Confirmation</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      background-color: #f9f9f9;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #ffffff;
      border: 1px solid #e0e0e0;
    }
    .header {
      text-align: center;
      padding: 20px 0;
      border-bottom: 1px solid #e0e0e0;
    }
    .logo {
      max-width: 150px;
      height: auto;
    }
    .content {
      padding: 20px 0;
    }
    .footer {
      text-align: center;
      padding: 20px 0;
      font-size: 12px;
      color: #777;
      border-top: 1px solid #e0e0e0;
    }
    .button {
      display: inline-block;
      padding: 10px 20px;
      background-color: #000000;
      color: #E5E4E2 !important;
      text-decoration: none;
      border-radius: 4px;
      margin: 20px 0;
    }
    .highlight {
      background-color: #f8f8f8;
      padding: 15px;
      border-left: 4px solid #000000;
      margin: 15px 0;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Bougie Billionaire Business</h1>
      <p>Luxury Barbados Concierge</p>
    </div>
    <div class="content">
      <h2>Subscription Upgrade Request Confirmation</h2>
      <p>Dear ${name},</p>
      <p>Thank you for your interest in upgrading to our <strong>${tierName}</strong> subscription plan. We have received your request and our team will contact you shortly to complete the process.</p>
      
      <div class="highlight">
        <p><strong>Request Details:</strong></p>
        <p>Email: ${email}<br>
        Requested Plan: ${tierName}</p>
      </div>
      
      <p>For your security, we process all payments through our secure payment platform that meets the highest industry standards for financial transactions. We never collect or store sensitive payment information in our chat interface.</p>
      
      <p>If you have any questions or need immediate assistance, please reply to this email or contact our premium support team.</p>
      
      <p>Best regards,<br>
      The Bougie Billionaire Team</p>
    </div>
    <div class="footer">
      <p>This email was sent to ${email} because you requested a subscription upgrade.</p>
      <p>&copy; 2023 Bougie Billionaire Business. All rights reserved.</p>
      <p>Our address: Luxury Lane, Bridgetown, Barbados</p>
    </div>
  </div>
</body>
</html>
  `
}
