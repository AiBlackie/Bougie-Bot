import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

// Define the feedback data structure
interface FeedbackData {
  messageId: string
  messageContent: string
  rating: "positive" | "negative"
  feedbackText: string
  timestamp: number
  sessionId: string
}

// In-memory cache for real-time feedback analysis
const feedbackCache: {
  recentFeedback: FeedbackData[]
  positiveCount: number
  negativeCount: number
  commonIssues: Record<string, number>
} = {
  recentFeedback: [],
  positiveCount: 0,
  negativeCount: 0,
  commonIssues: {},
}

// Function to save feedback to a JSON file
const saveFeedbackToFile = async (feedback: FeedbackData) => {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.join(process.cwd(), "data")
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true })
    }

    const feedbackFilePath = path.join(dataDir, "feedback.json")

    // Read existing feedback or create empty array
    let existingFeedback: FeedbackData[] = []
    if (fs.existsSync(feedbackFilePath)) {
      const fileContent = fs.readFileSync(feedbackFilePath, "utf-8")
      existingFeedback = JSON.parse(fileContent)
    }

    // Add new feedback
    existingFeedback.push(feedback)

    // Write back to file
    fs.writeFileSync(feedbackFilePath, JSON.stringify(existingFeedback, null, 2))

    return true
  } catch (error) {
    console.error("Error saving feedback:", error)
    return false
  }
}

// Function to update the in-memory feedback cache
const updateFeedbackCache = (feedback: FeedbackData) => {
  // Add to recent feedback (keep last 100 items)
  feedbackCache.recentFeedback.unshift(feedback)
  if (feedbackCache.recentFeedback.length > 100) {
    feedbackCache.recentFeedback.pop()
  }

  // Update counts
  if (feedback.rating === "positive") {
    feedbackCache.positiveCount++
  } else {
    feedbackCache.negativeCount++
  }

  // Extract keywords from negative feedback for analysis
  if (feedback.rating === "negative" && feedback.feedbackText) {
    const keywords = extractKeywords(feedback.feedbackText)
    keywords.forEach((keyword) => {
      feedbackCache.commonIssues[keyword] = (feedbackCache.commonIssues[keyword] || 0) + 1
    })
  }
}

// Simple keyword extraction (in a real system, use NLP)
const extractKeywords = (text: string): string[] => {
  const keywords = [
    "incorrect",
    "wrong",
    "inaccurate",
    "outdated",
    "confusing",
    "unclear",
    "vague",
    "missing",
    "incomplete",
    "not enough",
    "hotel",
    "restaurant",
    "beach",
    "activity",
    "price",
    "expensive",
    "cost",
    "location",
    "directions",
    "map",
  ]

  return keywords.filter((keyword) => text.toLowerCase().includes(keyword.toLowerCase()))
}

export async function POST(req: Request) {
  try {
    const feedback = (await req.json()) as FeedbackData

    // Validate feedback data
    if (!feedback.messageId || !feedback.rating) {
      return NextResponse.json({ error: "Invalid feedback data" }, { status: 400 })
    }

    // Save feedback to file
    const saved = await saveFeedbackToFile(feedback)

    // Update in-memory cache for real-time analysis
    updateFeedbackCache(feedback)

    if (!saved) {
      return NextResponse.json({ error: "Failed to save feedback" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error processing feedback:", error)
    return NextResponse.json({ error: "Failed to process feedback" }, { status: 500 })
  }
}

// GET endpoint to retrieve feedback analytics
export async function GET() {
  try {
    // Calculate feedback statistics
    const totalFeedback = feedbackCache.positiveCount + feedbackCache.negativeCount
    const positivePercentage = totalFeedback > 0 ? Math.round((feedbackCache.positiveCount / totalFeedback) * 100) : 0

    // Sort common issues by frequency
    const sortedIssues = Object.entries(feedbackCache.commonIssues)
      .sort(([, countA], [, countB]) => countB - countA)
      .slice(0, 5)
      .map(([issue, count]) => ({ issue, count }))

    return NextResponse.json({
      totalFeedback,
      positiveCount: feedbackCache.positiveCount,
      negativeCount: feedbackCache.negativeCount,
      positivePercentage,
      commonIssues: sortedIssues,
      recentFeedback: feedbackCache.recentFeedback.slice(0, 10), // Return only the 10 most recent
    })
  } catch (error) {
    console.error("Error retrieving feedback analytics:", error)
    return NextResponse.json({ error: "Failed to retrieve feedback analytics" }, { status: 500 })
  }
}
