// This file is no longer needed as we've consolidated the functionality into the main chat route
export async function POST(req: Request) {
  return new Response(JSON.stringify({ error: "This endpoint is deprecated" }), {
    status: 410,
    headers: { "Content-Type": "application/json" },
  })
}
