import { NextResponse } from "next/server"

// Barbados coordinates (not used in this implementation but kept for reference)
const BARBADOS_LAT = 13.1939
const BARBADOS_LON = -59.5432

export async function GET() {
  try {
    // Skip any external API calls and use our reliable fallback mechanism
    return NextResponse.json(getRealisticBarbadosWeather())
  } catch (error) {
    console.error("Error generating weather data:", error)
    // Use a simple fallback in case even our generator fails
    return NextResponse.json({
      temp: 28,
      description: "sunny",
      icon: "01d",
      humidity: 75,
      windSpeed: 5.0,
      isEstimate: true,
      lastUpdated: new Date().toISOString(),
    })
  }
}

// Function to generate realistic weather data for Barbados based on typical conditions
function getRealisticBarbadosWeather() {
  // Get current date to determine season
  const now = new Date()
  const month = now.getMonth() // 0-11 (January-December)

  // Barbados has a dry season (December to May) and a wet season (June to November)
  const isDrySeason = month <= 4 || month === 11 // December to May

  // Generate realistic temperature based on season
  // Barbados typically ranges from 25-30°C (77-86°F)
  const baseTemp = isDrySeason ? 28 : 29
  const tempVariation = Math.random() * 3 - 1.5 // -1.5 to +1.5 degrees variation
  const temp = Math.round(baseTemp + tempVariation)

  // Generate realistic humidity based on season
  // Dry season: 70-80%, Wet season: 75-85%
  const baseHumidity = isDrySeason ? 75 : 80
  const humidityVariation = Math.floor(Math.random() * 10)
  const humidity = baseHumidity + humidityVariation

  // Generate realistic wind speed (Barbados typically has trade winds of 5-10 mph)
  const baseWindSpeed = 5
  const windVariation = Math.random() * 5
  const windSpeed = +(baseWindSpeed + windVariation).toFixed(1)

  // Determine weather condition based on season and randomness
  let weatherCondition
  let icon

  const random = Math.random()

  if (isDrySeason) {
    if (random < 0.6) {
      // 60% chance of clear sky in dry season
      weatherCondition = "clear sky"
      icon = "01d"
    } else if (random < 0.9) {
      // 30% chance of few clouds
      weatherCondition = "few clouds"
      icon = "02d"
    } else {
      // 10% chance of scattered clouds
      weatherCondition = "scattered clouds"
      icon = "03d"
    }
  } else {
    // Wet season
    if (random < 0.4) {
      // 40% chance of clear sky in wet season
      weatherCondition = "clear sky"
      icon = "01d"
    } else if (random < 0.6) {
      // 20% chance of few clouds
      weatherCondition = "few clouds"
      icon = "02d"
    } else if (random < 0.8) {
      // 20% chance of scattered clouds
      weatherCondition = "scattered clouds"
      icon = "03d"
    } else if (random < 0.9) {
      // 10% chance of light rain
      weatherCondition = "light rain"
      icon = "10d"
    } else {
      // 10% chance of moderate rain
      weatherCondition = "moderate rain"
      icon = "09d"
    }
  }

  return {
    temp,
    description: weatherCondition,
    icon,
    humidity,
    windSpeed,
    isEstimate: true, // This is simulated data
    lastUpdated: new Date().toISOString(),
  }
}
