import { NextResponse } from "next/server"

// This would be replaced with your actual database logic
interface User {
  id: string
  email: string
  subscription: {
    tier: "free" | "basic" | "premium"
    startDate: string
    endDate: string | null
    paymentMethod: string | null
    selectedLanguage: string | null // For basic tier users who select one language
  }
}

// Mock user database - in a real app, this would be in a database
const users: Record<string, User> = {}

export async function POST(req: Request) {
  try {
    const { userId, plan, paymentDetails } = await req.json()

    if (!userId || !plan) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real implementation, you would:
    // 1. Validate the payment details
    // 2. Process the payment through a payment processor (Stripe, PayPal, etc.)
    // 3. Update the user's subscription in your database
    // 4. Return the updated subscription details

    // For this demo, we'll simulate a successful subscription
    const user = users[userId] || {
      id: userId,
      email: "user@example.com",
      subscription: {
        tier: "free",
        startDate: new Date().toISOString(),
        endDate: null,
        paymentMethod: null,
        selectedLanguage: null,
      },
    }

    // Update the user's subscription
    user.subscription = {
      tier: plan.tier,
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
      paymentMethod: "credit_card", // This would come from the payment processor
      selectedLanguage: plan.tier === "basic" ? null : user.subscription.selectedLanguage, // Reset if changing plans
    }

    // Save the user
    users[userId] = user

    // Return the updated subscription
    return NextResponse.json({
      success: true,
      subscription: user.subscription,
    })
  } catch (error) {
    console.error("Subscription error:", error)
    return NextResponse.json({ error: "Failed to process subscription" }, { status: 500 })
  }
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url)
    const userId = url.searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    const user = users[userId]

    if (!user) {
      // Return a default free subscription for new users
      return NextResponse.json({
        subscription: {
          tier: "free",
          startDate: new Date().toISOString(),
          endDate: null,
          paymentMethod: null,
          selectedLanguage: null,
        },
      })
    }

    return NextResponse.json({ subscription: user.subscription })
  } catch (error) {
    console.error("Error fetching subscription:", error)
    return NextResponse.json({ error: "Failed to fetch subscription" }, { status: 500 })
  }
}

export async function PUT(req: Request) {
  try {
    const { userId, selectedLanguage } = await req.json()

    if (!userId || !selectedLanguage) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const user = users[userId]

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Update the selected language for basic tier users
    if (user.subscription.tier === "basic") {
      user.subscription.selectedLanguage = selectedLanguage
      users[userId] = user
    }

    return NextResponse.json({
      success: true,
      subscription: user.subscription,
    })
  } catch (error) {
    console.error("Error updating language preference:", error)
    return NextResponse.json({ error: "Failed to update language preference" }, { status: 500 })
  }
}
