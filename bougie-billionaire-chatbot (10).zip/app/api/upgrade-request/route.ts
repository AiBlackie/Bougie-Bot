import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

// Define the upgrade request data structure
interface UpgradeRequest {
  email: string
  name?: string
  currentTier: string
  requestedTier: string
  timestamp: number
  userId: string
  additionalNotes?: string
}

// Function to save upgrade requests to a JSON file
const saveUpgradeRequest = async (request: UpgradeRequest) => {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.join(process.cwd(), "data")
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true })
    }

    const requestsFilePath = path.join(dataDir, "upgrade-requests.json")

    // Read existing requests or create empty array
    let existingRequests: UpgradeRequest[] = []
    if (fs.existsSync(requestsFilePath)) {
      const fileContent = fs.readFileSync(requestsFilePath, "utf-8")
      existingRequests = JSON.parse(fileContent)
    }

    // Add new request
    existingRequests.push(request)

    // Write back to file
    fs.writeFileSync(requestsFilePath, JSON.stringify(existingRequests, null, 2))

    // In a production environment, you would:
    // 1. Send an automatic confirmation email to the user
    // 2. Send a notification to the sales team
    // 3. Store the data in a secure database with encryption
    // 4. Log the request in a secure audit trail

    return true
  } catch (error) {
    console.error("Error saving upgrade request:", error)
    return false
  }
}

// Function to send confirmation email (mock implementation)
const sendConfirmationEmail = async (email: string, name: string, requestedTier: string) => {
  // In a production environment, this would use a secure email service like SendGrid, Mailgun, etc.
  console.log(`Sending confirmation email to ${email} for ${requestedTier} tier request`)

  // Return true to simulate successful email sending
  return true
}

export async function POST(req: Request) {
  try {
    const requestData = await req.json()

    // Validate required fields
    if (!requestData.email || !requestData.currentTier || !requestData.requestedTier || !requestData.userId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Format the upgrade request
    const upgradeRequest: UpgradeRequest = {
      email: requestData.email,
      name: requestData.name || "",
      currentTier: requestData.currentTier,
      requestedTier: requestData.requestedTier,
      timestamp: Date.now(),
      userId: requestData.userId,
      additionalNotes: requestData.additionalNotes || "",
    }

    // Save the request
    const saved = await saveUpgradeRequest(upgradeRequest)

    if (!saved) {
      return NextResponse.json({ error: "Failed to save upgrade request" }, { status: 500 })
    }

    // Send confirmation email
    const emailSent = await sendConfirmationEmail(
      upgradeRequest.email,
      upgradeRequest.name || "Valued Customer",
      upgradeRequest.requestedTier,
    )

    return NextResponse.json({
      success: true,
      message: "Upgrade request received. Our team will contact you shortly.",
      emailSent,
    })
  } catch (error) {
    console.error("Error processing upgrade request:", error)
    return NextResponse.json({ error: "Failed to process upgrade request" }, { status: 500 })
  }
}

// GET endpoint to retrieve upgrade requests (admin access only)
export async function GET(req: Request) {
  try {
    // In a real application, you would implement proper authentication here
    // to ensure only authorized administrators can access this data
    // This would include:
    // 1. JWT or session-based authentication
    // 2. Role-based access control
    // 3. IP restrictions
    // 4. Audit logging of all access attempts

    const url = new URL(req.url)
    const adminKey = url.searchParams.get("adminKey")

    // Simple admin key check (not secure for production)
    if (adminKey !== "bougie-admin-key") {
      return NextResponse.json({ error: "Unauthorized access" }, { status: 401 })
    }

    const dataDir = path.join(process.cwd(), "data")
    const requestsFilePath = path.join(dataDir, "upgrade-requests.json")

    if (!fs.existsSync(requestsFilePath)) {
      return NextResponse.json({ requests: [] })
    }

    const fileContent = fs.readFileSync(requestsFilePath, "utf-8")
    const requests = JSON.parse(fileContent)

    return NextResponse.json({ requests })
  } catch (error) {
    console.error("Error retrieving upgrade requests:", error)
    return NextResponse.json({ error: "Failed to retrieve upgrade requests" }, { status: 500 })
  }
}
