import { openai } from "@ai-sdk/openai"

export async function POST(req: Request) {
  try {
    const { apiKey } = await req.json()

    if (!apiKey) {
      return new Response(JSON.stringify({ error: "API key is required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    try {
      // Create a simple test request to OpenAI
      const model = openai("gpt-3.5-turbo", { apiKey })

      // Make a minimal request to test the API key
      const response = await fetch("https://api.openai.com/v1/models", {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        return new Response(
          JSON.stringify({
            error: errorData.error?.message || "Invalid API key or API request failed",
            status: response.status,
          }),
          { status: 400, headers: { "Content-Type": "application/json" } },
        )
      }

      return new Response(JSON.stringify({ success: true, message: "API key is valid" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      })
    } catch (error: any) {
      console.error("API key test error:", error)
      return new Response(
        JSON.stringify({
          error: error.message || "Failed to test API key",
          details: error.toString(),
        }),
        { status: 500, headers: { "Content-Type": "application/json" } },
      )
    }
  } catch (error: any) {
    console.error("Request parsing error:", error)
    return new Response(
      JSON.stringify({
        error: "Failed to process request",
        details: error.message || "Unknown error",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } },
    )
  }
}
