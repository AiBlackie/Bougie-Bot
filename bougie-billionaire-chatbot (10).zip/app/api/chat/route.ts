import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"
import { detectPremiumFeatures, hasFeatureAccess, generateFeaturePreview } from "@/utils/premium-features"

// Add language support to the fallback mode
function generateFallbackResponse(userMessage: string, language = "en", subscription = { tier: "free" }): string {
  // Check for premium features in the message
  const premiumFeatures = detectPremiumFeatures(userMessage)

  // If premium features are detected and user doesn't have access, return a preview
  if (premiumFeatures.length > 0) {
    const featureWithoutAccess = premiumFeatures.find((feature) => !hasFeatureAccess(feature, subscription))

    if (featureWithoutAccess) {
      return generateFeaturePreview(featureWithoutAccess)
    }
  }

  // Simple keyword-based responses for common Barbados tourism questions
  const keywords = {
    hotel:
      "Barbados offers several luxury hotels including Sandy Lane (call +1 (246) 444-2000), The Crane Resort (+1 (246) 423-6220), and Port Ferdinand Marina (+1 (246) 272-2000). These establishments provide world-class amenities, exceptional service, and stunning ocean views.",
    beach:
      "Barbados is renowned for its pristine beaches. The west coast (Platinum Coast) features calm waters perfect for swimming, while the east coast has dramatic landscapes and waves ideal for surfing.",
    dining:
      "The culinary scene in Barbados is exceptional. The Cliff Restaurant (+1 (246) 432-1922) offers fine dining with stunning sea views, while Champers (+1 (246) 434-3463) provides delicious seafood in an elegant setting. For a truly exclusive experience, consider a private chef at your villa.",
    activity:
      "Luxury activities in Barbados include private yacht charters, helicopter tours, polo matches at Holders Polo Club (+1 (246) 432-1802), and exclusive golf at Sandy Lane's renowned courses (+1 (246) 444-2000).",
    transport:
      "For luxury transportation in Barbados, consider private chauffeur services, helicopter transfers, or luxury car rentals. Many high-end resorts also offer airport pickup in premium vehicles.",
    shopping:
      "Limegrove Lifestyle Centre in Holetown (+1 (246) 271-8262) offers designer boutiques and luxury shopping. You'll find brands like Louis Vuitton, Ralph Lauren, and local high-end crafts and jewelry.",
    weather:
      "Barbados enjoys a tropical climate with temperatures typically between 75-85°F (24-29°C) year-round. The dry season runs from December to May, while the wet season is from June to November.",
    hello:
      "Hello! I'm your Bougie Bot specializing in luxury Barbados experiences. How can I assist you today with planning your exclusive Barbados getaway?",
    hi: "Greetings! I'm your Bougie Bot specializing in luxury Barbados experiences. How can I elevate your Barbados travel plans today?",
    hospital:
      "Barbados has excellent medical facilities including Queen Elizabeth Hospital (+1 (246) 436-6450) and Bayview Hospital (+1 (246) 436-5446). For emergencies, call 511 for an ambulance.",
    police:
      "The Royal Barbados Police Force has stations throughout the island. For emergencies, call 211. Tourist-friendly stations are located in Holetown (+1 (246) 419-1700), Bridgetown (+1 (246) 430-7100), and Oistins (+1 (246) 418-2612).",
    supermarket:
      "Major supermarkets in Barbados include Massy Stores (+1 (246) 432-5300), Trimart (+1 (246) 228-5100), and Popular Discounts (+1 (246) 426-1916). They offer a wide selection of local and imported products. Most are open from 8am to 9pm, with some locations open on Sundays.",
    pharmacy:
      "Pharmacies are widely available across Barbados. Massy Pharmacy (+1 (246) 432-5380), Knights Pharmacy (+1 (246) 426-0663), and Emerald City Pharmacy (+1 (246) 271-8365) are well-stocked with medications and health products. For emergencies, some locations offer extended hours.",
    clinic:
      "Medical clinics like Sandy Crest Medical Centre (+1 (246) 419-4911) provide 24-hour urgent care services for tourists and locals. They offer quality healthcare for non-emergency situations.",
    emergency:
      "For emergencies in Barbados, dial 511 for ambulance services, 211 for police assistance, and 311 for fire services. The Queen Elizabeth Hospital in Bridgetown (+1 (246) 436-6450) provides 24-hour emergency care.",
  }

  // Default response if no keywords match
  let response =
    "As your luxury Barbados concierge, I'd be delighted to provide information about exclusive resorts, dining, activities, and more. I can also help with essential services like hospitals, police stations, and supermarkets. Could you please specify what aspect of Barbados travel interests you most?"

  // Check for keyword matches
  const lowercaseMessage = userMessage.toLowerCase()
  for (const [keyword, reply] of Object.entries(keywords)) {
    if (lowercaseMessage.includes(keyword)) {
      response = reply
      break
    }
  }

  // If language is not English, translate the response
  if (language !== "en") {
    return translateFallbackResponse(response, language)
  }

  return response
}

// Simple mock translation function - in a real app, you would use a translation API
function translateFallbackResponse(text: string, targetLanguage: string): string {
  // This is a simplified mock translation - in a real app, you would use a proper translation service
  const translations: Record<string, Record<string, string>> = {
    fr: {
      "As your luxury Barbados concierge": "En tant que votre concierge de luxe à la Barbade",
      "I'd be delighted to provide information": "Je serais ravi de vous fournir des informations",
      "exclusive resorts": "complexes exclusifs",
      dining: "restauration",
      activities: "activités",
      "Could you please specify": "Pourriez-vous préciser",
    },
    es: {
      "As your luxury Barbados concierge": "Como su concierge de lujo en Barbados",
      "I'd be delighted to proporcionarle información": "Me encantaría proporcionarle información",
      "exclusive resorts": "resorts exclusivos",
      dining: "gastronomía",
      activities: "actividades",
      "Could you please specify": "¿Podría especificar",
    },
    de: {
      "As your luxury Barbados concierge": "Als Ihr Luxus-Concierge auf Barbados",
      "I'd be delighted to provide information": "Ich würde Ihnen gerne Informationen geben",
      "exclusive resorts": "exklusive Resorts",
      dining: "Gastronomie",
      activities: "Aktivitäten",
      "Could you please specify": "Könnten Sie bitte angeben",
    },
    // Add more languages as needed
  }

  // Very simple mock translation - just replace some key phrases
  // In a real app, you would use a proper translation API
  let translatedText = text
  if (translations[targetLanguage]) {
    const phrases = translations[targetLanguage]
    for (const [english, translated] of Object.entries(phrases)) {
      translatedText = translatedText.replace(new RegExp(english, "gi"), translated)
    }
  }

  // Add a note about the translation
  return translatedText + "\n\n[Translated to " + targetLanguage + "]"
}

// Load feedback data for improving responses
const loadFeedbackData = () => {
  try {
    const dataDir = path.join(process.cwd(), "data")
    const feedbackFilePath = path.join(dataDir, "feedback.json")

    if (fs.existsSync(feedbackFilePath)) {
      const fileContent = fs.readFileSync(feedbackFilePath, "utf-8")
      return JSON.parse(fileContent)
    }
    return []
  } catch (error) {
    console.error("Error loading feedback data:", error)
    return []
  }
}

// Extract insights from feedback to improve responses
const getFeedbackInsights = () => {
  const feedbackData = loadFeedbackData()

  // Group feedback by content to find problematic responses
  const contentFeedback: Record<string, { positive: number; negative: number; issues: string[] }> = {}

  feedbackData.forEach((feedback: any) => {
    const content = feedback.messageContent
    if (!contentFeedback[content]) {
      contentFeedback[content] = { positive: 0, negative: 0, issues: [] }
    }

    if (feedback.rating === "positive") {
      contentFeedback[content].positive++
    } else {
      contentFeedback[content].negative++
      if (feedback.feedbackText) {
        contentFeedback[content].issues.push(feedback.feedbackText)
      }
    }
  })

  // Find content with high negative feedback ratio
  const problematicResponses = Object.entries(contentFeedback)
    .filter(([, data]) => data.negative > data.positive && data.negative >= 2)
    .map(([content, data]) => ({
      content,
      negativeCount: data.negative,
      issues: data.issues,
    }))

  return {
    problematicResponses,
    totalFeedback: feedbackData.length,
  }
}

// Enhanced system prompt that incorporates feedback insights and expanded concierge capabilities
const getEnhancedSystemPrompt = (language = "en", subscription = { tier: "free" }) => {
  const insights = getFeedbackInsights()
  const tier = subscription.tier

  let enhancedPrompt = `
You are the AI Bougie Bot, a comprehensive luxury concierge for Barbados.

Your expertise includes:

ACCOMMODATIONS:
- Detailed profiles of luxury hotels, resorts, and private villas
- Room types, amenities, and exclusive features
- Pricing ranges and availability information
- Personalized accommodation recommendations based on preferences

DINING & CULINARY:
- Fine dining restaurants with signature dishes and ambiance descriptions
- Chef's tables and exclusive dining experiences
- Private chef arrangements for villas
- Wine pairing recommendations and champagne selections
- Dress codes and reservation policies

EXPERIENCES & ACTIVITIES:
- Private yacht charters and sailing excursions
- Exclusive island tours and hidden gems
- Luxury shopping destinations and boutiques
- VIP access to events (polo matches, festivals, golf tournaments)
- Spa and wellness retreats
- Water sports and adventure activities for luxury travelers

TRANSPORTATION:
- Private airport transfers and meet & greet services
- Luxury car rentals (exotic and premium vehicles)
- Helicopter transfers and island tours
- Chauffeur and limousine services

PERSONALIZED PLANNING:
- Custom itinerary creation based on preferences
- Special occasion planning (anniversaries, proposals, birthdays)
- VIP arrangements and exclusive access
- Seasonal recommendations and insider tips

ESSENTIAL SERVICES:
- Premium medical facilities and concierge doctors
- High-end security services
- Banking and currency exchange
- Emergency contacts and assistance

Always maintain a sophisticated, professional tone that reflects the B.O.U.G.I.E values:
B - Bread with God (Abundance + faith as your foundation)
O - Opportunity for Others (Lifting as you climb, wealth with impact)
U - Unapologetic Excellence (High standards, luxury, and quality)
G - Grateful & Giving (Billionaire mindset with humility)
I - Influence with Integrity (Power used for good)
E - Empire of Empathy (Wealth that cares and transforms)

IMPORTANT: Always provide actual phone numbers for businesses, emergency services, and other establishments. Do not mask, censor or replace digits with x's or asterisks. For example, use the actual format like "+1 (246) 444-2000" rather than "xxx-xxx-xxxx".

Provide detailed, personalized recommendations based on user queries. When making suggestions, consider:
- The user's stated or implied preferences
- Current season and weather in Barbados
- Appropriate pairings (accommodations with nearby dining, activities with transportation)
- Insider knowledge that would enhance their experience

For emergency services, always provide accurate contact information:
- Police Emergency: 211
- Ambulance/Medical Emergency: 511
- Fire Service: 311
`

  // Add subscription tier-specific instructions
  enhancedPrompt += `\n\nIMPORTANT: The user has a ${tier.toUpperCase()} subscription. `

  if (tier === "free") {
    enhancedPrompt += `For premium features like custom itinerary planning, VIP concierge services, or personalized recommendations, provide a brief preview and suggest upgrading to access the full feature. You can still provide general information about Barbados luxury experiences.`
  } else if (tier === "basic") {
    enhancedPrompt += `They have access to personalized recommendations and one additional language, but not to premium features like custom itinerary planning or VIP concierge services. For premium features, provide a more detailed preview and suggest upgrading to the Global Luxury plan for full access.`
  } else if (tier === "premium") {
    enhancedPrompt += `They have full access to all premium features including custom itinerary planning, VIP concierge services, personalized recommendations, and all language options. Provide the most detailed and exclusive information available.`
  }

  // Add language-specific instructions
  if (language !== "en") {
    enhancedPrompt += `\n\nIMPORTANT: The user has requested responses in ${language}. Please respond in ${language} rather than English. Maintain the same level of sophistication, detail, and helpfulness in your responses, but in ${language}.`
  }

  // Add feedback-based improvements if we have enough data
  if (insights.totalFeedback > 10) {
    enhancedPrompt += `\n\nBased on user feedback, please pay special attention to the following areas:`

    if (insights.problematicResponses.length > 0) {
      enhancedPrompt += `\n- Provide specific details about locations, including exact addresses when available`
      enhancedPrompt += `\n- Include price ranges and booking information when discussing accommodations or experiences`
      enhancedPrompt += `\n- When mentioning a location, include its position on the island (west coast, east coast, etc.)`

      // Add specific issues from feedback
      const commonIssues = insights.problematicResponses
        .flatMap((r) => r.issues)
        .filter(Boolean)
        .slice(0, 3)

      if (commonIssues.length > 0) {
        enhancedPrompt += `\n\nUsers have specifically mentioned these issues with previous responses:`
        commonIssues.forEach((issue) => {
          enhancedPrompt += `\n- ${issue}`
        })
      }
    }
  }

  return enhancedPrompt
}

// System prompt that specializes the AI in Barbados tourism
const getSystemPrompt = (language = "en", subscription = { tier: "free" }) =>
  getEnhancedSystemPrompt(language, subscription)

// Check if user has access to the requested language
const hasLanguageAccess = (
  requestedLanguage: string,
  subscription: { tier: string; selectedLanguage: string | null },
): boolean => {
  // English is always accessible
  if (requestedLanguage === "en") return true

  // Premium subscribers have access to all languages
  if (subscription.tier === "premium") return true

  // Basic subscribers have access to English and their selected language
  if (subscription.tier === "basic") {
    return subscription.selectedLanguage === requestedLanguage
  }

  // Free users only have access to English
  return false
}

export async function POST(req: Request) {
  try {
    // Extract the messages, API key, and language from the request body
    const body = await req.json()
    const messages = body.messages || []
    const apiKey = body.apiKey
    const useFallback = body.useFallback === true
    const language = body.language || "en"
    const userId = body.userId
    const subscription = body.subscription || { tier: "free", selectedLanguage: null }

    // Check if user has access to the requested language
    const hasAccess = hasLanguageAccess(language, subscription)
    if (!hasAccess) {
      return NextResponse.json(
        {
          error: "Language access restricted",
          type: "language_restricted",
          details: "You need to upgrade your subscription to access this language",
        },
        { status: 403 },
      )
    }

    // Get the last user message for fallback mode
    let lastUserMessage = ""
    if (Array.isArray(messages)) {
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].role === "user") {
          lastUserMessage = messages[i].content
          break
        }
      }
    }

    // Check for premium features in the message
    const premiumFeatures = detectPremiumFeatures(lastUserMessage)

    // If premium features are detected and user doesn't have access, return a preview
    if (premiumFeatures.length > 0) {
      const featureWithoutAccess = premiumFeatures.find((feature) => !hasFeatureAccess(feature, subscription))

      if (featureWithoutAccess) {
        return NextResponse.json({
          role: "assistant",
          content: generateFeaturePreview(featureWithoutAccess),
          id: Date.now().toString(),
          isPremiumPreview: true,
          premiumFeature: featureWithoutAccess,
          language,
        })
      }
    }

    // Use fallback mode if specified or if there's an issue with the API key
    if (useFallback || !apiKey || typeof apiKey !== "string" || !apiKey.startsWith("sk-")) {
      const fallbackContent = generateFallbackResponse(lastUserMessage, language, subscription)
      return NextResponse.json({
        role: "assistant",
        content: fallbackContent,
        id: Date.now().toString(),
        isFallback: true,
        language,
      })
    }

    // Format messages for OpenAI API
    const formattedMessages = [
      {
        role: "system",
        content: getSystemPrompt(language, subscription),
      },
    ]

    // Add user and assistant messages
    if (Array.isArray(messages)) {
      for (const message of messages) {
        if (message && typeof message === "object" && message.role && message.content) {
          // Explicitly set role to avoid toLowerCase() issues
          let role = "user"
          if (message.role === "assistant") {
            role = "assistant"
          } else if (message.role === "system") {
            role = "system"
          }

          formattedMessages.push({
            role: role,
            content: String(message.content),
          })
        }
      }
    }

    // Make a direct fetch to OpenAI API
    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: formattedMessages,
        temperature: 0.7,
        max_tokens: 800,
      }),
    })

    if (!openaiResponse.ok) {
      const errorData = await openaiResponse.json()
      throw new Error(errorData.error?.message || `OpenAI API error: ${openaiResponse.statusText}`)
    }

    const data = await openaiResponse.json()
    const responseMessage = data.choices[0].message

    // Return the response
    return NextResponse.json({
      role: responseMessage.role,
      content: responseMessage.content,
      id: Date.now().toString(),
      language,
    })
  } catch (error: any) {
    console.error("Error in chat API:", error)

    // Check for quota exceeded error
    const errorMessage = error.message || "An error occurred while processing your request"
    const isQuotaError =
      errorMessage.includes("exceeded your current quota") || errorMessage.includes("billing details")

    if (isQuotaError) {
      return NextResponse.json(
        {
          error: "OpenAI API quota exceeded. Please check your billing details or try a different API key.",
          type: "quota_exceeded",
          details:
            "Your OpenAI account has reached its usage limit. You may need to add a payment method or upgrade your plan at https://platform.openai.com/account/billing",
        },
        { status: 402 }, // Payment Required status code
      )
    }

    // Return a detailed error response for other errors
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
