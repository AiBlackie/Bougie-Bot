"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ThumbsUp, ThumbsDown, RefreshCw, AlertTriangle, CheckCircle, BarChart } from "lucide-react"

interface FeedbackAnalytics {
  totalFeedback: number
  positiveCount: number
  negativeCount: number
  positivePercentage: number
  commonIssues: { issue: string; count: number }[]
  recentFeedback: {
    messageId: string
    messageContent: string
    rating: "positive" | "negative"
    feedbackText: string
    timestamp: number
    sessionId: string
  }[]
}

export default function FeedbackDashboard() {
  const [analytics, setAnalytics] = useState<FeedbackAnalytics | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchAnalytics = async () => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/feedback")
      if (!response.ok) {
        throw new Error("Failed to fetch feedback analytics")
      }

      const data = await response.json()
      setAnalytics(data)
    } catch (err) {
      console.error("Error fetching analytics:", err)
      setError("Failed to load feedback data. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAnalytics()

    // Refresh data every 5 minutes
    const interval = setInterval(fetchAnalytics, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  // Format timestamp to readable date
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  return (
    <div className="container max-w-6xl px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-platinum">AI Bougie Bot Feedback Dashboard</h1>
        <Button
          onClick={fetchAnalytics}
          variant="outline"
          className="border-platinum/30 text-platinum hover:bg-gray-800"
          disabled={loading}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Refresh Data
        </Button>
      </div>

      {error && (
        <Card className="bg-red-900/20 border-red-500/50 mb-6">
          <CardContent className="pt-6">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-red-400 mt-0.5" />
              <p className="text-red-200">{error}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {loading && !analytics ? (
        <div className="flex justify-center items-center h-64">
          <div className="flex flex-col items-center">
            <div className="h-12 w-12 border-4 border-platinum border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-platinum/70">Loading feedback data...</p>
          </div>
        </div>
      ) : (
        <>
          {/* Analytics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-gray-900/90 border-platinum/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-platinum text-lg">Total Feedback</CardTitle>
                <CardDescription className="text-platinum/70">All user feedback collected</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-3xl font-bold text-platinum">{analytics?.totalFeedback || 0}</span>
                  <BarChart className="h-8 w-8 text-platinum/50" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/90 border-platinum/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-platinum text-lg">Positive Feedback</CardTitle>
                <CardDescription className="text-platinum/70">Responses rated as helpful</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-3xl font-bold text-green-400">{analytics?.positiveCount || 0}</span>
                    <span className="text-sm text-platinum/70 ml-2">({analytics?.positivePercentage || 0}%)</span>
                  </div>
                  <ThumbsUp className="h-8 w-8 text-green-400/70" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/90 border-platinum/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-platinum text-lg">Negative Feedback</CardTitle>
                <CardDescription className="text-platinum/70">Responses rated as not helpful</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-3xl font-bold text-red-400">{analytics?.negativeCount || 0}</span>
                    <span className="text-sm text-platinum/70 ml-2">
                      (
                      {analytics?.totalFeedback
                        ? Math.round((analytics.negativeCount / analytics.totalFeedback) * 100)
                        : 0}
                      %)
                    </span>
                  </div>
                  <ThumbsDown className="h-8 w-8 text-red-400/70" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Common Issues */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-gray-900/90 border-platinum/30 md:col-span-1">
              <CardHeader>
                <CardTitle className="text-platinum text-lg">Common Issues</CardTitle>
                <CardDescription className="text-platinum/70">Frequently reported problems</CardDescription>
              </CardHeader>
              <CardContent>
                {analytics?.commonIssues && analytics.commonIssues.length > 0 ? (
                  <div className="space-y-2">
                    {analytics.commonIssues.map((issue, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm text-platinum/80">{issue.issue}</span>
                        <Badge variant="outline" className="bg-gray-800/50 text-platinum/70">
                          {issue.count}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-platinum/60">No common issues identified yet.</p>
                )}
              </CardContent>
            </Card>

            {/* Recent Feedback */}
            <Card className="bg-gray-900/90 border-platinum/30 md:col-span-2">
              <CardHeader>
                <CardTitle className="text-platinum text-lg">Recent Feedback</CardTitle>
                <CardDescription className="text-platinum/70">Latest user feedback received</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px] pr-4">
                  {analytics?.recentFeedback && analytics.recentFeedback.length > 0 ? (
                    <div className="space-y-4">
                      {analytics.recentFeedback.map((feedback, index) => (
                        <Card key={index} className="bg-gray-800/50 border-platinum/20">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-2">
                              <div className="flex items-center">
                                {feedback.rating === "positive" ? (
                                  <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                                ) : (
                                  <AlertTriangle className="h-4 w-4 text-red-400 mr-2" />
                                )}
                                <span className="text-xs text-platinum/60">{formatDate(feedback.timestamp)}</span>
                              </div>
                              <Badge
                                variant="outline"
                                className={`${
                                  feedback.rating === "positive"
                                    ? "border-green-500/30 text-green-400"
                                    : "border-red-500/30 text-red-400"
                                }`}
                              >
                                {feedback.rating === "positive" ? "Helpful" : "Not Helpful"}
                              </Badge>
                            </div>
                            <p className="text-sm text-platinum/80 mb-2 bg-gray-900/50 p-2 rounded border border-platinum/10">
                              {feedback.messageContent.length > 100
                                ? `${feedback.messageContent.substring(0, 100)}...`
                                : feedback.messageContent}
                            </p>
                            {feedback.feedbackText && (
                              <div className="bg-gray-900/70 p-2 rounded border border-platinum/10">
                                <p className="text-xs text-platinum/70 italic">{feedback.feedbackText}</p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-platinum/60">No feedback received yet.</p>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Learning Impact */}
          <Card className="bg-gray-900/90 border-platinum/30 mb-6">
            <CardHeader>
              <CardTitle className="text-platinum text-lg">Learning Impact</CardTitle>
              <CardDescription className="text-platinum/70">How feedback is improving AI Bougie Bot</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-platinum/80">
                  AI Bougie Bot uses feedback in several ways to continuously improve:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
                    <h3 className="font-medium text-platinum mb-1">Real-time Adjustments</h3>
                    <p className="text-xs text-platinum/70">
                      Negative feedback is immediately analyzed to adjust future responses on similar topics.
                    </p>
                  </div>
                  <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
                    <h3 className="font-medium text-platinum mb-1">System Prompt Enhancement</h3>
                    <p className="text-xs text-platinum/70">
                      Common issues are incorporated into the system prompt to guide the AI toward better responses.
                    </p>
                  </div>
                  <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
                    <h3 className="font-medium text-platinum mb-1">Knowledge Base Updates</h3>
                    <p className="text-xs text-platinum/70">
                      Feedback helps identify knowledge gaps about Barbados that need to be addressed.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
