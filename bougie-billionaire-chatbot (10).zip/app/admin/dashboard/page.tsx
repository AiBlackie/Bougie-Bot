"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RefreshCw, Users, CreditCard, TrendingUp, Mail } from "lucide-react"
import Link from "next/link"

export default function AdminDashboard() {
  const [upgradeRequests, setUpgradeRequests] = useState(0)
  const [loading, setLoading] = useState(true)

  const fetchData = async () => {
    setLoading(true)
    try {
      // In a real app, this would be authenticated
      const response = await fetch("/api/upgrade-request?adminKey=bougie-admin-key")
      if (response.ok) {
        const data = await response.json()
        setUpgradeRequests(data.requests?.length || 0)
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  return (
    <div className="container max-w-6xl px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-platinum">Admin Dashboard</h1>
        <Button
          onClick={fetchData}
          variant="outline"
          className="border-platinum/30 text-platinum hover:bg-gray-800"
          disabled={loading}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Refresh Data
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gray-900/90 border-platinum/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-platinum text-lg">Users</CardTitle>
            <CardDescription className="text-platinum/70">Total registered users</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-platinum">128</span>
              <Users className="h-8 w-8 text-platinum/50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900/90 border-platinum/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-platinum text-lg">Subscriptions</CardTitle>
            <CardDescription className="text-platinum/70">Active paid subscriptions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-platinum">42</span>
              <CreditCard className="h-8 w-8 text-platinum/50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900/90 border-platinum/30 relative overflow-hidden">
          <div className="absolute top-0 right-0">
            {upgradeRequests > 0 && (
              <div className="bg-amber-600 text-white text-xs font-bold px-2 py-1 m-2 rounded-full">
                {upgradeRequests} New
              </div>
            )}
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-platinum text-lg">Upgrade Requests</CardTitle>
            <CardDescription className="text-platinum/70">Pending subscription upgrades</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-platinum">{upgradeRequests}</span>
              <Mail className="h-8 w-8 text-platinum/50" />
            </div>
            <div className="mt-4">
              <Link href="/admin/upgrade-requests">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full border-platinum/30 text-platinum hover:bg-gray-800"
                >
                  View Requests
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-900/90 border-platinum/30 mb-6">
        <CardHeader>
          <CardTitle className="text-platinum text-lg">Revenue Overview</CardTitle>
          <CardDescription className="text-platinum/70">Monthly subscription revenue</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center">
            <div className="text-center">
              <TrendingUp className="h-16 w-16 text-platinum/30 mx-auto mb-4" />
              <p className="text-platinum/70">Revenue chart would be displayed here</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
