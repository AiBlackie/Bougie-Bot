"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  RefreshCw,
  Mail,
  Calendar,
  User,
  Crown,
  Star,
  Globe,
  AlertTriangle,
  CheckCircle,
  Shield,
  Lock,
} from "lucide-react"
import { Input } from "@/components/ui/input"

interface UpgradeRequest {
  email: string
  name?: string
  currentTier: string
  requestedTier: string
  timestamp: number
  userId: string
  additionalNotes?: string
}

export default function UpgradeRequestsDashboard() {
  const [requests, setRequests] = useState<UpgradeRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [adminKey, setAdminKey] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const fetchRequests = async () => {
    if (!adminKey) return

    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/upgrade-request?adminKey=${adminKey}`)
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("Invalid admin key")
        }
        throw new Error("Failed to fetch upgrade requests")
      }

      const data = await response.json()
      setRequests(data.requests || [])
      setIsAuthenticated(true)
    } catch (err: any) {
      console.error("Error fetching requests:", err)
      setError(err.message || "Failed to load upgrade requests. Please try again.")
      setIsAuthenticated(false)
    } finally {
      setLoading(false)
    }
  }

  const handleAuthenticate = (e: React.FormEvent) => {
    e.preventDefault()
    fetchRequests()
  }

  // Format timestamp to readable date
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  // Get tier badge color
  const getTierBadgeColor = (tier: string) => {
    switch (tier) {
      case "free":
        return "bg-gray-600"
      case "basic":
        return "bg-blue-600"
      case "premium":
        return "bg-amber-600"
      default:
        return "bg-gray-600"
    }
  }

  // Get tier icon
  const getTierIcon = (tier: string) => {
    switch (tier) {
      case "free":
        return <Globe className="h-3.5 w-3.5" />
      case "basic":
        return <Star className="h-3.5 w-3.5" />
      case "premium":
        return <Crown className="h-3.5 w-3.5" />
      default:
        return <Globe className="h-3.5 w-3.5" />
    }
  }

  return (
    <div className="container max-w-6xl px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-platinum">Upgrade Requests Dashboard</h1>
        {isAuthenticated && (
          <Button
            onClick={fetchRequests}
            variant="outline"
            className="border-platinum/30 text-platinum hover:bg-gray-800"
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Refresh Data
          </Button>
        )}
      </div>

      {!isAuthenticated ? (
        <Card className="bg-gray-900/90 border-platinum/30 mb-6">
          <CardHeader>
            <CardTitle className="text-platinum">Admin Authentication</CardTitle>
            <CardDescription className="text-platinum/70">
              Enter your admin key to view upgrade requests
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAuthenticate} className="space-y-4">
              <div className="space-y-2">
                <Input
                  type="password"
                  placeholder="Enter admin key"
                  value={adminKey}
                  onChange={(e) => setAdminKey(e.target.value)}
                  className="bg-gray-800 border-platinum/30 text-white"
                />
                {error && (
                  <div className="text-sm text-red-400">
                    <AlertTriangle className="h-4 w-4 inline mr-1" />
                    {error}
                  </div>
                )}
              </div>
              <Button type="submit" className="bg-platinum hover:bg-platinum/80 text-black">
                Authenticate
              </Button>
            </form>
          </CardContent>
        </Card>
      ) : (
        <>
          {error && (
            <Card className="bg-red-900/20 border-red-500/50 mb-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-400 mt-0.5" />
                  <p className="text-red-200">{error}</p>
                </div>
              </CardContent>
            </Card>
          )}

          <Card className="bg-gray-900/90 border-platinum/30 mb-6">
            <CardHeader className="pb-2">
              <CardTitle className="text-platinum text-lg flex items-center gap-2">
                <Shield className="h-5 w-5 text-platinum/70" />
                Security Notice
              </CardTitle>
              <CardDescription className="text-platinum/70">
                Important information about handling customer data
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg mb-4">
                <div className="flex items-start gap-2">
                  <Lock className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-blue-300 font-medium">Data Protection Guidelines</p>
                    <ul className="text-xs text-blue-300/80 mt-1 space-y-1 list-disc list-inside">
                      <li>Never store customer payment information in this system</li>
                      <li>Use secure, encrypted channels when contacting customers about their subscription</li>
                      <li>Direct customers to our secure payment portal to complete transactions</li>
                      <li>Comply with all applicable privacy laws and regulations when handling customer data</li>
                      <li>Report any security concerns or data breaches immediately to the security team</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="flex flex-col items-center">
                <div className="h-12 w-12 border-4 border-platinum border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-platinum/70">Loading upgrade requests...</p>
              </div>
            </div>
          ) : (
            <>
              <Card className="bg-gray-900/90 border-platinum/30 mb-6">
                <CardHeader className="pb-2">
                  <CardTitle className="text-platinum text-lg">Upgrade Requests Summary</CardTitle>
                  <CardDescription className="text-platinum/70">
                    Overview of subscription upgrade requests
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
                      <h3 className="font-medium text-platinum mb-1">Total Requests</h3>
                      <p className="text-2xl font-bold text-platinum">{requests.length}</p>
                    </div>
                    <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
                      <h3 className="font-medium text-platinum mb-1">Language Plus Requests</h3>
                      <p className="text-2xl font-bold text-blue-400">
                        {requests.filter((r) => r.requestedTier === "basic").length}
                      </p>
                    </div>
                    <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
                      <h3 className="font-medium text-platinum mb-1">Global Luxury Requests</h3>
                      <p className="text-2xl font-bold text-amber-400">
                        {requests.filter((r) => r.requestedTier === "premium").length}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/90 border-platinum/30">
                <CardHeader>
                  <CardTitle className="text-platinum text-lg">Upgrade Requests</CardTitle>
                  <CardDescription className="text-platinum/70">
                    Users who have expressed interest in upgrading their subscription
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[500px] pr-4">
                    {requests.length > 0 ? (
                      <div className="space-y-4">
                        {requests.map((request, index) => (
                          <Card key={index} className="bg-gray-800/50 border-platinum/20">
                            <CardContent className="p-4">
                              <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4 mb-3">
                                <div>
                                  <h3 className="font-bold text-platinum flex items-center gap-2">
                                    <Mail className="h-4 w-4 text-platinum/70" />
                                    {request.email}
                                  </h3>
                                  {request.name && (
                                    <p className="text-sm text-platinum/80 flex items-center gap-2 mt-1">
                                      <User className="h-4 w-4 text-platinum/60" />
                                      {request.name}
                                    </p>
                                  )}
                                </div>
                                <div className="text-sm text-platinum/70 flex items-center gap-2">
                                  <Calendar className="h-4 w-4 text-platinum/60" />
                                  {formatDate(request.timestamp)}
                                </div>
                              </div>

                              <div className="flex flex-wrap gap-3 mb-3">
                                <div className="flex items-center gap-1">
                                  <span className="text-xs text-platinum/70">From:</span>
                                  <Badge className={`${getTierBadgeColor(request.currentTier)} text-white px-2 py-0.5`}>
                                    <span className="flex items-center gap-1">
                                      {getTierIcon(request.currentTier)}
                                      {request.currentTier === "free"
                                        ? "Free"
                                        : request.currentTier === "basic"
                                          ? "Language Plus"
                                          : "Global Luxury"}
                                    </span>
                                  </Badge>
                                </div>

                                <div className="flex items-center gap-1">
                                  <span className="text-xs text-platinum/70">To:</span>
                                  <Badge
                                    className={`${getTierBadgeColor(request.requestedTier)} text-white px-2 py-0.5`}
                                  >
                                    <span className="flex items-center gap-1">
                                      {getTierIcon(request.requestedTier)}
                                      {request.requestedTier === "free"
                                        ? "Free"
                                        : request.requestedTier === "basic"
                                          ? "Language Plus"
                                          : "Global Luxury"}
                                    </span>
                                  </Badge>
                                </div>
                              </div>

                              {request.additionalNotes && (
                                <div className="bg-gray-900/70 p-3 rounded border border-platinum/10 mt-3">
                                  <p className="text-sm text-platinum/80 font-medium mb-1">Additional Notes:</p>
                                  <p className="text-sm text-platinum/70">{request.additionalNotes}</p>
                                </div>
                              )}

                              <div className="flex justify-end mt-3">
                                <Button
                                  size="sm"
                                  className="bg-platinum hover:bg-platinum/80 text-black"
                                  onClick={() => window.open(`mailto:${request.email}`)}
                                >
                                  <Mail className="h-3.5 w-3.5 mr-1.5" />
                                  Contact User
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <CheckCircle className="h-12 w-12 mx-auto text-platinum/30 mb-4" />
                        <p className="text-platinum/70">No upgrade requests found</p>
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </>
          )}
        </>
      )}
    </div>
  )
}
