"use client"
import { useState, useEffect, useCallback } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Bot, MapIcon, Info, MapPin, List } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import dynamic from "next/dynamic"
import { BotAvatar } from "@/components/bot-avatar"
import { UserAvatar } from "@/components/user-avatar"
import { StarsBackground } from "@/components/stars-background"
import { WeatherTimeDisplay } from "@/components/weather-time-display"
import { MessageBubble } from "@/components/message-bubble"
import { InfoSources } from "@/components/info-sources"
import { TimeBasedBackground } from "@/components/time-based-background"
import { FeedbackInterface, type FeedbackData } from "@/components/feedback-interface"
// Add these imports at the top of the file
import { LanguageSelector } from "@/components/language-selector"
import { SubscriptionManager, type SubscriptionTier, type SubscriptionPlan } from "@/components/subscription-manager"
// Add these imports at the top of the file
import { SubscriptionStatus } from "@/components/subscription-status"
import { PremiumFeaturePreview } from "@/components/premium-feature-preview"
import type { PremiumFeatureType } from "@/utils/premium-features"

// Dynamically import the BarbadosMap component with no SSR and with a loading fallback
const BarbadosMap = dynamic(() => import("@/components/barbados-map"), {
  ssr: false,
  loading: () => (
    <div className="h-[500px] flex items-center justify-center bg-gray-800 text-platinum/70">
      <div className="text-center">
        <div className="mb-4 animate-pulse">
          <div className="h-16 w-16 mx-auto rounded-full bg-platinum/20"></div>
        </div>
        <p>Loading map of Barbados...</p>
      </div>
    </div>
  ),
})

// Dynamically import the LocationsDirectory component
const LocationsDirectory = dynamic(() => import("@/components/locations-directory"), {
  ssr: false,
  loading: () => (
    <div className="h-[500px] flex items-center justify-center bg-gray-800 text-platinum/70">
      <div className="text-center">
        <div className="mb-4 animate-pulse">
          <div className="h-16 w-16 mx-auto rounded-full bg-platinum/20"></div>
        </div>
        <p>Loading luxury locations directory...</p>
      </div>
    </div>
  ),
})

// Message type definition
interface Message {
  id: string
  role: "user" | "assistant" | "system"
  content: string
}

// List of luxury locations to detect in messages
const luxuryLocationNames = [
  "Sandy Lane Hotel",
  "The Crane Resort",
  "Port Ferdinand Marina",
  "Limegrove Lifestyle Centre",
  "The Cliff Restaurant",
  "Nikki Beach Barbados",
  "Platinum Coast",
  "Fairmont Royal Pavilion",
  "Coral Reef Club",
  "The House by Elegant Hotels",
  "Cobblers Cove",
  "Colony Club",
  "Treasure Beach",
  "Animal Flower Cave",
  "St. Nicholas Abbey",
  "Cin Cin By The Sea",
]

export default function Home() {
  const [apiKey, setApiKey] = useState("")
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("chat")
  const [chatError, setChatError] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [useFallbackMode, setUseFallbackMode] = useState(false)
  const [mapError, setMapError] = useState(false)
  const [highlightedLocation, setHighlightedLocation] = useState<string | null>(null)
  const [mentionedLocations, setMentionedLocations] = useState<string[]>([])
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [feedbackError, setFeedbackError] = useState<string | null>(null)
  // Add these state variables inside the Home component
  const [selectedLanguage, setSelectedLanguage] = useState("en")
  const [subscription, setSubscription] = useState<SubscriptionTier>("free")
  const [userId, setUserId] = useState("")
  const [showSubscriptionDialog, setShowSubscriptionDialog] = useState(false)
  // Inside the Home component, add this state variable
  const [premiumFeaturePreview, setPremiumFeaturePreview] = useState<PremiumFeatureType | null>(null)

  // Load API key from localStorage on component mount
  useEffect(() => {
    try {
      const savedApiKey = localStorage.getItem("openai_api_key")
      if (savedApiKey) {
        setApiKey(savedApiKey)
      } else {
        // Show settings dialog if no API key is found
        setIsSettingsOpen(true)
      }

      // Check if fallback mode was previously enabled
      const fallbackMode = localStorage.getItem("use_fallback_mode") === "true"
      setUseFallbackMode(fallbackMode)
    } catch (error) {
      console.error("Error loading settings:", error)
    }
    // Add this useEffect to generate and store a user ID
    // Generate a user ID if one doesn't exist
    const storedUserId = localStorage.getItem("user_id")
    if (storedUserId) {
      setUserId(storedUserId)
    } else {
      const newUserId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
      localStorage.setItem("user_id", newUserId)
      setUserId(newUserId)
    }

    // Load subscription status
    const storedSubscription = localStorage.getItem("subscription_tier")
    if (storedSubscription) {
      setSubscription(storedSubscription as SubscriptionTier)
    }

    // Load selected language
    const storedLanguage = localStorage.getItem("selected_language")
    if (storedLanguage) {
      setSelectedLanguage(storedLanguage)
    }
  }, [])

  // Clear error when API key changes
  useEffect(() => {
    setChatError(null)
  }, [apiKey])

  // Add a welcome message when API key is set or fallback mode is enabled
  useEffect(() => {
    if ((apiKey || useFallbackMode) && messages.length === 0) {
      setMessages([
        {
          id: "welcome-message",
          role: "assistant",
          content:
            "Welcome to AI Bougie Bot, your luxury Barbados Concierge. I can assist with exclusive accommodations, fine dining reservations, private yacht charters, VIP experiences, personalized itineraries, and more. How may I enhance your Barbados experience today?",
        },
      ])
    }
  }, [apiKey, useFallbackMode, messages.length])

  // Function to detect locations in a message
  const detectLocations = useCallback((content: string) => {
    const foundLocations: string[] = []

    luxuryLocationNames.forEach((location) => {
      if (content.toLowerCase().includes(location.toLowerCase())) {
        foundLocations.push(location)
      }
    })

    return foundLocations
  }, [])

  // Update mentioned locations when messages change
  useEffect(() => {
    const newMentionedLocations: string[] = []

    messages.forEach((message) => {
      const locationsInMessage = detectLocations(message.content)
      locationsInMessage.forEach((location) => {
        if (!newMentionedLocations.includes(location)) {
          newMentionedLocations.push(location)
        }
      })
    })

    setMentionedLocations(newMentionedLocations)
  }, [messages, detectLocations])

  const saveApiKey = useCallback(
    (newKey: string) => {
      // Trim whitespace
      const trimmedKey = newKey.trim()

      if (!trimmedKey && !useFallbackMode) {
        alert("Please enter an OpenAI API key or enable fallback mode")
        return
      }

      if (trimmedKey && !trimmedKey.startsWith("sk-")) {
        alert("Please enter a valid OpenAI API key. It should start with 'sk-'")
        return
      }

      try {
        // Save to state and localStorage
        setApiKey(trimmedKey)
        localStorage.setItem("openai_api_key", trimmedKey)
        setIsSettingsOpen(false)

        // Clear messages and errors when API key changes
        setMessages([])
        setChatError(null)

        // Show confirmation
        alert("Settings saved successfully! You can now chat with the bot.")
      } catch (error) {
        console.error("Error saving API key:", error)
        alert("Failed to save settings. Please try again.")
      }
    },
    [useFallbackMode],
  )

  const toggleFallbackMode = useCallback((enabled: boolean) => {
    setUseFallbackMode(enabled)
    localStorage.setItem("use_fallback_mode", enabled.toString())

    // Clear messages when switching modes
    setMessages([])
    setChatError(null)
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }

  // Add these functions to handle language and subscription changes
  const handleLanguageChange = (languageCode: string) => {
    setSelectedLanguage(languageCode)
    localStorage.setItem("selected_language", languageCode)
  }

  const handleSubscriptionUpgrade = async (plan: SubscriptionPlan): Promise<boolean> => {
    try {
      // In a real app, this would make an API call to process payment and update subscription
      // For this demo, we'll simulate a successful subscription
      setSubscription(plan.tier)
      localStorage.setItem("subscription_tier", plan.tier)

      // Close the dialog after successful subscription
      setTimeout(() => {
        setShowSubscriptionDialog(false)
      }, 1000)

      return true
    } catch (error) {
      console.error("Subscription upgrade error:", error)
      return false
    }
  }

  // Update the handleSubmit function to include language and subscription info
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim() || isLoading) return
    if (!apiKey && !useFallbackMode) {
      setChatError("Please set an API key or enable fallback mode in settings")
      return
    }

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)
    setChatError(null)

    try {
      // Send request to API with the API key and language
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          apiKey: apiKey,
          useFallback: useFallbackMode,
          language: selectedLanguage,
          userId: userId,
          subscription: {
            tier: subscription,
            selectedLanguage: selectedLanguage !== "en" ? selectedLanguage : null,
          },
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()

        // Handle language restriction error
        if (errorData.type === "language_restricted") {
          throw new Error(`This language requires a subscription upgrade. Please upgrade to access this language.`)
        }

        // Handle quota exceeded error specifically
        if (errorData.type === "quota_exceeded") {
          throw new Error(`OpenAI API quota exceeded. Please check your billing details or try a different API key.`)
        }

        throw new Error(errorData.error || "Failed to get response")
      }

      const data = await response.json()

      // Inside the try block of handleSubmit, after the fetch but before adding the assistant message:
      if (data.isPremiumPreview && data.premiumFeature) {
        setPremiumFeaturePreview(data.premiumFeature as PremiumFeatureType)
      }

      // Add assistant message
      setMessages((prev) => [
        ...prev,
        {
          id: data.id || Date.now().toString(),
          role: "assistant",
          content: data.content,
        },
      ])

      // Check for locations in the response
      const locationsInResponse = detectLocations(data.content)
      if (locationsInResponse.length > 0) {
        setHighlightedLocation(locationsInResponse[0])
      }

      // If a location is mentioned, switch to the map tab
      if (locationsInResponse.length > 0 && activeTab !== "map") {
        // Optional: automatically switch to map tab when a location is mentioned
        // setActiveTab("map")
      }
    } catch (error: any) {
      console.error("Chat error:", error)
      setChatError(error.message || "Failed to communicate with the chatbot")

      // Add a fallback response for quota errors
      if (error.message && error.message.includes("quota exceeded")) {
        setMessages((prev) => [
          ...prev,
          {
            id: "quota-error-message",
            role: "assistant",
            content:
              "I apologize, but it seems your OpenAI API key has reached its usage limit. To continue our conversation, you'll need to:\n\n1. Visit your [OpenAI billing dashboard](https://platform.openai.com/account/billing)\n2. Add a payment method or upgrade your plan\n3. Or try a different API key with available quota\n\nAlternatively, you can enable fallback mode in settings to use a simplified version of the chatbot that doesn't require an API key.",
          },
        ])
      }

      // Add a fallback response for language restriction errors
      if (error.message && error.message.includes("language requires a subscription upgrade")) {
        setMessages((prev) => [
          ...prev,
          {
            id: "language-restriction-message",
            role: "assistant",
            content:
              "I apologize, but multilingual capabilities are a premium feature. To chat in languages other than English, you'll need to upgrade your subscription. Would you like to see our subscription options?",
          },
        ])
        // Show subscription dialog
        setShowSubscriptionDialog(true)
      }
    } finally {
      setIsLoading(false)
    }
  }

  // Handle map tab click - prepare for map loading
  const handleMapTabClick = useCallback(() => {
    setMapError(false)
  }, [])

  // Handle location click in chat
  const handleLocationClick = (location: string) => {
    setHighlightedLocation(location)
    setActiveTab("map")
  }

  // Handle category selection
  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId)
  }

  // Handle feedback submission
  const handleFeedbackSubmit = async (feedback: FeedbackData) => {
    try {
      setFeedbackError(null)

      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(feedback),
      })

      if (!response.ok) {
        throw new Error("Failed to submit feedback")
      }

      return await response.json()
    } catch (error) {
      console.error("Feedback error:", error)
      setFeedbackError("Failed to submit feedback. Please try again.")
      throw error
    }
  }

  // Render location mentions with clickable links
  const renderMessageWithLocationLinks = (content: string) => {
    let renderedContent = content

    luxuryLocationNames.forEach((location) => {
      const regex = new RegExp(`(${location})`, "gi")
      renderedContent = renderedContent.replace(regex, `<span class="location-mention">$1</span>`)
    })

    return (
      <div
        dangerouslySetInnerHTML={{ __html: renderedContent }}
        onClick={(e) => {
          const target = e.target as HTMLElement
          if (target.classList.contains("location-mention")) {
            handleLocationClick(target.textContent || "")
          }
        }}
      />
    )
  }

  return (
    <TimeBasedBackground>
      <div className="container max-w-4xl px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-platinum mb-2">Bougie Billionaire Business</h1>
          <p className="text-xl italic text-platinum/80">"Elevate your mind and spirit towards true abundance"</p>
        </div>

        <Card className="bg-gray-900/90 border-platinum border-2 shadow-lg shadow-platinum/20">
          <CardHeader className="border-b border-platinum/30 flex flex-row justify-between items-center">
            <CardTitle className="flex items-center gap-2 text-platinum">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-platinum to-platinum/70 p-1.5">
                <Bot className="h-full w-full text-black" />
              </div>
              AI Bougie Bot - Barbados Concierge
            </CardTitle>

            <div className="flex items-center gap-2">
              <SubscriptionStatus currentTier={subscription} onUpgradeSubscription={handleSubscriptionUpgrade} />
              <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
                <DialogContent className="bg-gray-900 border-platinum text-white">
                  <DialogHeader>
                    <DialogTitle className="text-platinum">API Settings</DialogTitle>
                    <DialogDescription className="text-gray-400">
                      Configure your chatbot settings below.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="fallbackMode" className="text-white">
                          Fallback Mode
                        </Label>
                        <div className="flex items-center">
                          <input
                            id="fallbackMode"
                            type="checkbox"
                            checked={useFallbackMode}
                            onChange={(e) => toggleFallbackMode(e.target.checked)}
                            className="mr-2 h-4 w-4"
                          />
                          <span className="text-sm text-gray-300">{useFallbackMode ? "Enabled" : "Disabled"}</span>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400">
                        Enable fallback mode to use a simplified version of the chatbot that doesn't require an API key.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="apiKey" className="text-white flex items-center gap-1">
                        OpenAI API Key
                        {useFallbackMode && <span className="text-xs text-gray-400">(Optional in fallback mode)</span>}
                      </Label>
                      <div className="flex gap-2">
                        <Input
                          id="apiKey"
                          type="password"
                          placeholder="sk-..."
                          value={apiKey}
                          onChange={(e) => setApiKey(e.target.value)}
                          className="bg-gray-800 border-platinum/30 text-white"
                          disabled={useFallbackMode}
                        />
                        <Button
                          onClick={() => saveApiKey(apiKey)}
                          className="bg-platinum hover:bg-platinum/80 text-black"
                        >
                          Save
                        </Button>
                      </div>
                      <p className="text-xs text-gray-400 mt-2">
                        Your API key is stored locally in your browser and is only sent to OpenAI for processing your
                        requests.
                      </p>
                      {!useFallbackMode && (
                        <>
                          <div className="mt-4 p-3 bg-gray-800/50 rounded-lg border border-platinum/30 text-sm">
                            <p className="font-semibold text-platinum mb-1">How to get an OpenAI API key:</p>
                            <ol className="list-decimal list-inside space-y-1 text-gray-300">
                              <li>
                                Go to{" "}
                                <a
                                  href="https://platform.openai.com/signup"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-platinum underline"
                                >
                                  OpenAI's website
                                </a>{" "}
                                and create an account
                              </li>
                              <li>
                                Navigate to the{" "}
                                <a
                                  href="https://platform.openai.com/api-keys"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-platinum underline"
                                >
                                  API keys section
                                </a>
                              </li>
                              <li>Click "Create new secret key"</li>
                              <li>Copy the key (it starts with "sk-") and paste it here</li>
                            </ol>
                          </div>

                          <div className="mt-4 p-3 bg-gray-800/50 rounded-lg border border-platinum/30 text-sm">
                            <p className="font-semibold text-platinum mb-1">API Quota Issues?</p>
                            <p className="text-gray-300 mb-2">
                              If you're experiencing quota limits with your OpenAI API key:
                            </p>
                            <ol className="list-decimal list-inside space-y-1 text-gray-300">
                              <li>
                                Visit your{" "}
                                <a
                                  href="https://platform.openai.com/account/billing"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-platinum underline"
                                >
                                  OpenAI billing dashboard
                                </a>
                              </li>
                              <li>Add a payment method if you haven't already</li>
                              <li>Check your usage limits and current plan</li>
                              <li>Consider upgrading your plan for higher usage limits</li>
                            </ol>
                            <p className="text-gray-300 mt-2">
                              Free tier accounts have limited monthly usage. Paid accounts have higher limits based on
                              your plan.
                            </p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs
              defaultValue="chat"
              className="w-full"
              value={activeTab}
              onValueChange={(value) => {
                setActiveTab(value)
                if (value === "map") {
                  handleMapTabClick()
                }
              }}
            >
              <TabsList className="grid grid-cols-3 bg-gray-800 rounded-none border-b border-platinum/30">
                <TabsTrigger value="chat" className="data-[state=active]:bg-gray-900 data-[state=active]:text-platinum">
                  <div className="flex items-center gap-2">
                    <Bot className="h-4 w-4" />
                    Chat
                  </div>
                </TabsTrigger>
                <TabsTrigger value="map" className="data-[state=active]:bg-gray-900 data-[state=active]:text-platinum">
                  <div className="flex items-center gap-2">
                    <MapIcon className="h-4 w-4" />
                    Map
                  </div>
                </TabsTrigger>
                <TabsTrigger
                  value="locations"
                  className="data-[state=active]:bg-gray-900 data-[state=active]:text-platinum"
                >
                  <div className="flex items-center gap-2">
                    <List className="h-4 w-4" />
                    Locations
                  </div>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="chat" className="mt-0">
                {/* Weather and Time Display */}
                <div className="px-4 pt-4 pb-2">
                  <WeatherTimeDisplay />
                </div>

                {/* Information Sources */}
                <div className="px-4 pb-2">
                  <InfoSources />
                </div>

                {/* Mentioned Locations */}
                {mentionedLocations.length > 0 && (
                  <div className="px-4 pb-2">
                    <Card className="bg-gray-900/70 border-platinum/30 p-3">
                      <div className="flex items-start gap-2">
                        <MapPin className="h-5 w-5 text-platinum/90 mt-0.5 flex-shrink-0" />
                        <div>
                          <h3 className="font-semibold text-platinum mb-1">Mentioned Locations</h3>
                          <div className="flex flex-wrap gap-2">
                            {mentionedLocations.map((location, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className="bg-gray-800/50 border-platinum/20 text-platinum/90 hover:bg-gray-700/50 text-xs"
                                onClick={() => {
                                  setHighlightedLocation(location)
                                  setActiveTab("map")
                                }}
                              >
                                <MapPin className="h-3 w-3 mr-1" />
                                {location}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>
                )}

                <div className="relative">
                  {/* Stars Background */}
                  <StarsBackground />

                  <ScrollArea className="h-[400px] p-4 relative z-10">
                    {messages.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center p-8 text-gray-400">
                        <div className="h-16 w-16 rounded-full bg-gradient-to-r from-platinum to-platinum/70 p-2 mb-4">
                          <Bot className="h-full w-full text-black" />
                        </div>
                        <p className="text-lg mb-2">Welcome to Bougie Billionaire Business</p>
                        <p>Ask me about luxury hotels, exclusive experiences, and tourism opportunities in Barbados!</p>
                        <p className="mt-2">
                          Check out the Map tab to explore the beautiful island of Barbados visually.
                        </p>

                        {!apiKey && !useFallbackMode && (
                          <div className="mt-6 p-3 bg-gray-800/50 rounded-lg border border-platinum/30 text-sm">
                            <p className="font-semibold text-platinum mb-1">⚠️ API Key Required</p>
                            <p>Please set your OpenAI API key in the settings to use the chatbot.</p>
                            <Button
                              onClick={() => setIsSettingsOpen(true)}
                              variant="outline"
                              size="sm"
                              className="mt-2 border-platinum/50 text-platinum hover:bg-gray-800"
                            >
                              Open Settings
                            </Button>
                          </div>
                        )}

                        {useFallbackMode && (
                          <div className="mt-6 p-3 bg-gray-800/50 rounded-lg border border-platinum/30 text-sm">
                            <div className="flex items-center gap-2 text-platinum mb-1">
                              <Info className="h-4 w-4" />
                              <p className="font-semibold">Fallback Mode Active</p>
                            </div>
                            <p>You're using a simplified version of the chatbot with limited responses.</p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <>
                        {chatError && (
                          <div className="p-3 bg-red-900/30 border border-red-500/50 rounded-lg mb-4 text-sm">
                            <p className="font-semibold text-red-400 mb-1">⚠️ Error</p>
                            <p className="text-red-200">{chatError}</p>
                            <Button
                              onClick={() => setChatError(null)}
                              variant="outline"
                              size="sm"
                              className="mt-2 border-red-500/50 text-red-400 hover:bg-red-900/50"
                            >
                              Dismiss
                            </Button>
                          </div>
                        )}

                        {useFallbackMode && (
                          <div className="p-3 bg-gray-800/50 border border-platinum/30 rounded-lg mb-4 text-xs">
                            <div className="flex items-center gap-1 text-platinum/80 mb-1">
                              <Info className="h-3 w-3" />
                              <p>Fallback Mode Active - Using simplified responses</p>
                            </div>
                          </div>
                        )}

                        {feedbackError && (
                          <div className="p-3 bg-red-900/30 border border-red-500/50 rounded-lg mb-4 text-xs">
                            <div className="flex items-center gap-1 text-red-400 mb-1">
                              <Info className="h-3 w-3" />
                              <p>{feedbackError}</p>
                            </div>
                          </div>
                        )}

                        <div className="flex flex-col gap-4">
                          {messages.map((message) => (
                            <div
                              key={message.id}
                              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                            >
                              <div
                                className={`flex gap-2 max-w-[80%] ${
                                  message.role === "user" ? "flex-row-reverse" : "flex-row"
                                }`}
                              >
                                {message.role === "user" ? <UserAvatar /> : <BotAvatar />}
                                <div className="flex flex-col">
                                  <MessageBubble
                                    content={message.content}
                                    isUser={message.role === "user"}
                                    renderContent={() => renderMessageWithLocationLinks(message.content)}
                                  />
                                  {message.role === "assistant" && (
                                    <FeedbackInterface
                                      messageId={message.id}
                                      messageContent={message.content}
                                      onFeedbackSubmit={handleFeedbackSubmit}
                                    />
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                    {premiumFeaturePreview && (
                      <PremiumFeaturePreview
                        featureType={premiumFeaturePreview}
                        subscription={subscription}
                        onUpgradeSubscription={handleSubscriptionUpgrade}
                      />
                    )}
                  </ScrollArea>
                </div>

                {/* Now add the language selector to the chat form
                Find the form element with onSubmit={handleSubmit} and add the LanguageSelector before the Input */}
                <form onSubmit={handleSubmit} className="border-t border-platinum/30 p-4 flex gap-2">
                  <LanguageSelector
                    selectedLanguage={selectedLanguage}
                    onLanguageChange={handleLanguageChange}
                    subscription={subscription}
                    onUpgradeSubscription={handleSubscriptionUpgrade}
                  />
                  <Input
                    value={input}
                    onChange={handleInputChange}
                    placeholder="Ask about luxury accommodations, dining, experiences, or itinerary planning..."
                    className="bg-gray-800 border-platinum/30 focus-visible:ring-platinum text-white"
                    disabled={(!apiKey && !useFallbackMode) || isLoading}
                  />
                  <Button
                    type="submit"
                    disabled={isLoading || !input.trim() || (!apiKey && !useFallbackMode)}
                    className="bg-platinum hover:bg-platinum/80 text-black"
                  >
                    {isLoading ? (
                      <div className="h-4 w-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="map" className="mt-0 h-[500px]">
                <BarbadosMap highlightedLocation={highlightedLocation} />
              </TabsContent>

              <TabsContent value="locations" className="mt-0 h-[500px]">
                <LocationsDirectory
                  selectedCategory={selectedCategory}
                  onCategorySelect={handleCategorySelect}
                  onLocationSelect={(location) => {
                    setHighlightedLocation(location)
                    setActiveTab("map")
                  }}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      {/* Add this Dialog for subscription management
      Add this right before the closing </TimeBasedBackground> tag */}
      <Dialog open={showSubscriptionDialog} onOpenChange={setShowSubscriptionDialog}>
        <DialogContent className="bg-gray-900 border-platinum/30 text-platinum max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">Upgrade Your Bougie Experience</DialogTitle>
            <DialogDescription className="text-platinum/70">
              Unlock multilingual capabilities for your luxury Barbados concierge
            </DialogDescription>
          </DialogHeader>

          <SubscriptionManager
            currentTier={subscription}
            onSubscribe={handleSubscriptionUpgrade}
            onClose={() => setShowSubscriptionDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </TimeBasedBackground>
  )
}
