"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Crown, Star, Lock, Sparkles } from "lucide-react"
import { SubscriptionManager, type SubscriptionTier, type SubscriptionPlan } from "@/components/subscription-manager"
import { type PremiumFeatureType, premiumFeatures } from "@/utils/premium-features"

interface PremiumFeaturePreviewProps {
  featureType: PremiumFeatureType
  subscription: SubscriptionTier
  onUpgradeSubscription: (plan: SubscriptionPlan) => Promise<boolean>
}

export function PremiumFeaturePreview({
  featureType,
  subscription,
  onUpgradeSubscription,
}: PremiumFeaturePreviewProps) {
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false)

  const feature = premiumFeatures[featureType]
  const requiredTier = feature.tier

  return (
    <>
      <Card className="bg-gray-800/70 border-amber-500/30 p-4 my-3">
        <div className="flex items-start gap-3">
          <div className="bg-amber-600/20 p-2 rounded-full">
            <Lock className="h-5 w-5 text-amber-500" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-medium text-amber-400 flex items-center gap-2 mb-1">
              Premium Feature
              {requiredTier === "premium" ? (
                <Crown className="h-3.5 w-3.5 text-amber-400" />
              ) : (
                <Star className="h-3.5 w-3.5 text-blue-400" />
              )}
            </h3>
            <p className="text-xs text-platinum/80 mb-3">
              {feature.description} requires a{" "}
              <span className={requiredTier === "premium" ? "text-amber-400" : "text-blue-400"}>
                {requiredTier === "premium" ? "Global Luxury" : "Language Plus"}
              </span>{" "}
              subscription.
            </p>

            {feature.previewAvailable && (
              <div className="bg-gray-900/50 p-2 rounded border border-platinum/20 mb-3">
                <div className="flex items-center gap-1 mb-1">
                  <Sparkles className="h-3 w-3 text-amber-400" />
                  <span className="text-xs font-medium text-platinum/90">Preview Available</span>
                </div>
                <p className="text-xs text-platinum/70">{feature.previewLimit}</p>
              </div>
            )}

            <Button
              size="sm"
              onClick={() => setShowUpgradeDialog(true)}
              className={`${
                requiredTier === "premium" ? "bg-amber-600 hover:bg-amber-500" : "bg-blue-600 hover:bg-blue-500"
              } text-white text-xs`}
            >
              Upgrade to Unlock
            </Button>
          </div>
        </div>
      </Card>

      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="bg-gray-900 border-platinum/30 text-platinum max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">Upgrade to Access Premium Features</DialogTitle>
          </DialogHeader>

          <SubscriptionManager
            currentTier={subscription}
            onSubscribe={onUpgradeSubscription}
            onClose={() => setShowUpgradeDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  )
}
