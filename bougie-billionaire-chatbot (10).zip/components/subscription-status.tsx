"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Crown, Star, Globe, Info, ChevronRight } from "lucide-react"
import { SubscriptionManager, type SubscriptionTier, type SubscriptionPlan } from "@/components/subscription-manager"

interface SubscriptionStatusProps {
  currentTier: SubscriptionTier
  onUpgradeSubscription: (plan: SubscriptionPlan) => Promise<boolean>
}

export function SubscriptionStatus({ currentTier, onUpgradeSubscription }: SubscriptionStatusProps) {
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false)

  // Define tier-specific details
  const tierDetails = {
    free: {
      name: "Free",
      icon: <Globe className="h-3.5 w-3.5" />,
      color: "bg-gray-600 hover:bg-gray-500",
      description: "Basic English concierge services",
    },
    basic: {
      name: "Language Plus",
      icon: <Star className="h-3.5 w-3.5" />,
      color: "bg-blue-600 hover:bg-blue-500",
      description: "English plus one additional language",
    },
    premium: {
      name: "Global Luxury",
      icon: <Crown className="h-3.5 w-3.5" />,
      color: "bg-amber-600 hover:bg-amber-500",
      description: "Full multilingual VIP experience",
    },
  }

  const tier = tierDetails[currentTier]

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setShowUpgradeDialog(true)}
        className={`h-7 px-2 border-none ${tier.color} text-white text-xs gap-1 rounded-full`}
      >
        {tier.icon}
        <span>{tier.name}</span>
        {currentTier !== "premium" && <ChevronRight className="h-3 w-3 ml-0.5" />}
      </Button>

      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="bg-gray-900 border-platinum/30 text-platinum max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">Your Subscription</DialogTitle>
          </DialogHeader>

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={`${tier.color.split(" ")[0]} text-white px-2 py-0.5`}>
                <span className="flex items-center gap-1">
                  {tier.icon}
                  {tier.name}
                </span>
              </Badge>
              <span className="text-platinum/80 text-sm">Current Plan</span>
            </div>

            <p className="text-sm text-platinum/70">{tier.description}</p>

            {currentTier === "free" && (
              <div className="mt-4 p-3 bg-gray-800/50 rounded-lg border border-platinum/20">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-platinum/70 mt-0.5" />
                  <div>
                    <p className="text-sm text-platinum/90 mb-1">Upgrade to unlock premium features:</p>
                    <ul className="text-xs text-platinum/70 space-y-1 list-disc list-inside">
                      <li>Multilingual support in up to 9 languages</li>
                      <li>Custom itinerary planning for your Barbados trip</li>
                      <li>VIP concierge services and exclusive recommendations</li>
                      <li>Priority response times and 24/7 support</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>

          <SubscriptionManager
            currentTier={currentTier}
            onSubscribe={onUpgradeSubscription}
            onClose={() => setShowUpgradeDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  )
}
