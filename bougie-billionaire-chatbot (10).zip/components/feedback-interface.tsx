"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ThumbsUp, ThumbsDown, Send, X } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"

interface FeedbackInterfaceProps {
  messageId: string
  messageContent: string
  onFeedbackSubmit: (feedback: FeedbackData) => Promise<void>
}

export interface FeedbackData {
  messageId: string
  messageContent: string
  rating: "positive" | "negative"
  feedbackText: string
  timestamp: number
  sessionId: string
}

export function FeedbackInterface({ messageId, messageContent, onFeedbackSubmit }: FeedbackInterfaceProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [feedbackText, setFeedbackText] = useState("")
  const [rating, setRating] = useState<"positive" | "negative" | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [quickFeedbackGiven, setQuickFeedbackGiven] = useState(false)

  const handleQuickFeedback = async (newRating: "positive" | "negative") => {
    if (quickFeedbackGiven) return

    setRating(newRating)
    setQuickFeedbackGiven(true)

    // Submit quick feedback without opening dialog
    try {
      const sessionId = localStorage.getItem("session_id") || `session_${Date.now()}`
      if (!localStorage.getItem("session_id")) {
        localStorage.setItem("session_id", sessionId)
      }

      const feedbackData: FeedbackData = {
        messageId,
        messageContent,
        rating: newRating,
        feedbackText: "",
        timestamp: Date.now(),
        sessionId,
      }

      await onFeedbackSubmit(feedbackData)
    } catch (error) {
      console.error("Failed to submit quick feedback:", error)
    }
  }

  const handleDetailedFeedback = async () => {
    if (!rating) return

    setIsSubmitting(true)

    try {
      const sessionId = localStorage.getItem("session_id") || `session_${Date.now()}`
      if (!localStorage.getItem("session_id")) {
        localStorage.setItem("session_id", sessionId)
      }

      const feedbackData: FeedbackData = {
        messageId,
        messageContent,
        rating,
        feedbackText,
        timestamp: Date.now(),
        sessionId,
      }

      await onFeedbackSubmit(feedbackData)
      setIsDialogOpen(false)
      setFeedbackText("")
    } catch (error) {
      console.error("Failed to submit feedback:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex items-center justify-end mt-1 space-x-1">
      {!quickFeedbackGiven ? (
        <>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs text-platinum/60 hover:text-platinum/90 hover:bg-gray-800/50"
            onClick={() => handleQuickFeedback("positive")}
          >
            <ThumbsUp className="h-3 w-3 mr-1" />
            Helpful
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs text-platinum/60 hover:text-platinum/90 hover:bg-gray-800/50"
            onClick={() => {
              setRating("negative")
              setIsDialogOpen(true)
            }}
          >
            <ThumbsDown className="h-3 w-3 mr-1" />
            Not Helpful
          </Button>
        </>
      ) : (
        <>
          <span className="text-xs text-platinum/60">
            {rating === "positive" ? "Thanks for your feedback!" : "Thanks for your feedback!"}
          </span>
          {rating === "negative" && !isDialogOpen && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 px-2 text-xs text-platinum/60 hover:text-platinum/90 hover:bg-gray-800/50"
              onClick={() => setIsDialogOpen(true)}
            >
              Tell us more
            </Button>
          )}
        </>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-gray-900 border-platinum/30 text-platinum">
          <DialogHeader>
            <DialogTitle>Help us improve</DialogTitle>
            <DialogDescription className="text-platinum/70">
              Please tell us how we can make this response better.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <p className="text-sm text-platinum/80 bg-gray-800/50 p-2 rounded border border-platinum/20">
                {messageContent.length > 150 ? `${messageContent.substring(0, 150)}...` : messageContent}
              </p>
              <Textarea
                placeholder="What was wrong with this response? How could it be improved?"
                value={feedbackText}
                onChange={(e) => setFeedbackText(e.target.value)}
                className="bg-gray-800 border-platinum/30 text-white min-h-[100px]"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <DialogClose asChild>
              <Button variant="outline" className="border-platinum/30 text-platinum hover:bg-gray-800">
                <X className="h-4 w-4 mr-1" />
                Cancel
              </Button>
            </DialogClose>
            <Button
              onClick={handleDetailedFeedback}
              disabled={isSubmitting || !feedbackText.trim()}
              className="bg-platinum hover:bg-platinum/80 text-black"
            >
              {isSubmitting ? (
                <div className="h-4 w-4 border-2 border-black border-t-transparent rounded-full animate-spin mr-1"></div>
              ) : (
                <Send className="h-4 w-4 mr-1" />
              )}
              Submit Feedback
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
