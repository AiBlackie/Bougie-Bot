import { Card } from "@/components/ui/card"
import { Info } from "lucide-react"

export function InfoSources() {
  return (
    <Card className="bg-gray-900/70 border-platinum/30 p-3 text-platinum/80 text-sm">
      <div className="flex items-start gap-2">
        <Info className="h-5 w-5 text-platinum/90 mt-0.5 flex-shrink-0" />
        <div>
          <h3 className="font-semibold text-platinum mb-1">About AI Bougie Bot</h3>
          <p className="text-xs mb-2">AI Bougie Bot is your comprehensive luxury Barbados concierge, offering:</p>
          <ul className="list-disc list-inside text-xs space-y-1">
            <li>Detailed profiles of luxury accommodations with amenities and availability</li>
            <li>Fine dining recommendations and reservation assistance</li>
            <li>Exclusive experiences including yacht charters and VIP events</li>
            <li>Private transportation arrangements and luxury car rentals</li>
            <li>Personalized itinerary planning based on your preferences</li>
            <li>Real-time weather data and local insights</li>
            <li>Interactive map with premium locations across the island</li>
            <li>Essential services information (hospitals, police, etc.)</li>
          </ul>
          <p className="text-xs mt-2 italic">
            For the most up-to-date information, we recommend confirming details with specific venues or the Barbados
            Tourism Authority.
          </p>
        </div>
      </div>
    </Card>
  )
}
