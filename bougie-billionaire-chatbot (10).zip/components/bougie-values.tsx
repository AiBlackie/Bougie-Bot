"use client"

import { useState } from "react"

export function BougieValues() {
  const [expandedValue, setExpandedValue] = useState<string | null>(null)

  const values = {
    B: {
      title: "Bread with God",
      description:
        "Abundance and faith as your foundation. Recognizing that true wealth begins with spiritual alignment and gratitude for divine provision.",
    },
    O: {
      title: "Opportunity for Others",
      description:
        "Lifting as you climb, creating wealth with impact. Using your success to create pathways for others to achieve their own prosperity.",
    },
    U: {
      title: "Unapologetic Excellence",
      description:
        "Maintaining high standards, luxury, and quality in all endeavors. Never compromising on the pursuit of the extraordinary.",
    },
    G: {
      title: "Grateful & Giving",
      description:
        "Embracing a billionaire mindset with humility. Recognizing that true wealth is measured by what you give, not what you have.",
    },
    I: {
      title: "Influence with Integrity",
      description:
        "Using power for good. Leading with honesty and ethical principles that inspire others to follow your example.",
    },
    E: {
      title: "Empire of Empathy",
      description:
        "Building wealth that cares and transforms. Creating a legacy that prioritizes human connection and positive social impact.",
    },
  }

  const handleClick = (letter: string) => {
    if (expandedValue === letter) {
      setExpandedValue(null)
    } else {
      setExpandedValue(letter)
    }
  }

  return (
    <div className="mt-8 text-center">
      <div className="bougie-title-container mb-6">
        <h2 className="text-3xl font-bold bougie-sparkle-text">B.O.U.G.I.E</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bougie-values">
        {Object.entries(values).map(([letter, { title, description }]) => (
          <div
            key={letter}
            className={`bg-gray-900/50 p-3 rounded border border-platinum/20 cursor-pointer transition-all duration-300 ${
              expandedValue === letter ? "md:col-span-3 shadow-lg shadow-platinum/10" : ""
            }`}
            onClick={() => handleClick(letter)}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-platinum">
                <span className="text-xl mr-1">{letter}</span> - {title}
              </h3>
              <span className="text-xs text-platinum/70">
                {expandedValue === letter ? "Click to collapse" : "Click to expand"}
              </span>
            </div>

            {expandedValue === letter && (
              <p className="mt-2 text-sm text-platinum/80 bg-black/30 p-2 rounded">{description}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
