"use client"

import { useEffect, useState, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Search, MapPin, Star, Globe, Phone, Navigation, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { luxuryLocations, categoryGroups, categories } from "@/data/locations"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Simple static map component as fallback
function StaticMap() {
  return (
    <div className="h-full flex flex-col items-center justify-center bg-gray-800 text-platinum/70 p-6">
      <div className="text-center mb-6">
        <h3 className="text-xl font-semibold text-platinum mb-2">Barbados Map</h3>
        <p className="text-sm text-platinum/70 mb-4">
          Interactive map is currently unavailable. Here's a list of locations in Barbados:
        </p>
      </div>

      <div className="w-full max-w-md bg-gray-900/50 rounded-lg border border-platinum/20 p-4 overflow-y-auto max-h-[400px]">
        {luxuryLocations.map((location, index) => (
          <div key={index} className="mb-4 pb-4 border-b border-platinum/10 last:border-0">
            <h4 className="font-bold text-platinum">{location.name}</h4>
            <p className="text-sm text-platinum/70 mt-1">{location.description}</p>
            <p className="text-xs text-platinum/50 mt-1">
              Location: {location.position[0].toFixed(4)}, {location.position[1].toFixed(4)}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

interface BarbadosMapProps {
  highlightedLocation?: string | null
}

export default function BarbadosMap({ highlightedLocation = null }: BarbadosMapProps) {
  const [mapLoaded, setMapLoaded] = useState(false)
  const [loadError, setLoadError] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<typeof luxuryLocations>([])
  const [selectedLocation, setSelectedLocation] = useState<(typeof luxuryLocations)[0] | null>(null)
  const [visibleCategories, setVisibleCategories] = useState<string[]>(categories.map((cat) => cat.id))
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markersRef = useRef<any[]>([])

  // Handle search
  const handleSearch = () => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    const query = searchQuery.toLowerCase()
    const results = luxuryLocations.filter(
      (location) =>
        location.name.toLowerCase().includes(query) ||
        location.description.toLowerCase().includes(query) ||
        (location.type && location.type.toLowerCase().includes(query)),
    )

    setSearchResults(results)
  }

  // Focus on a location
  const focusOnLocation = (location: (typeof luxuryLocations)[0]) => {
    if (!mapInstanceRef.current) return

    setSelectedLocation(location)
    mapInstanceRef.current.setView(location.position, 15)
  }

  // Toggle category visibility
  const toggleCategory = (categoryId: string) => {
    setVisibleCategories((prev) => {
      if (prev.includes(categoryId)) {
        return prev.filter((id) => id !== categoryId)
      } else {
        return [...prev, categoryId]
      }
    })
  }

  // Toggle category group visibility
  const toggleCategoryGroup = (groupId: string) => {
    const groupCategories = categoryGroups.find((g) => g.id === groupId)?.categories || []

    // Check if all categories in the group are currently visible
    const allVisible = groupCategories.every((catId) => visibleCategories.includes(catId))

    if (allVisible) {
      // Remove all categories in this group
      setVisibleCategories((prev) => prev.filter((id) => !groupCategories.includes(id)))
    } else {
      // Add all categories in this group
      setVisibleCategories((prev) => {
        const newCategories = [...prev]
        groupCategories.forEach((catId) => {
          if (!newCategories.includes(catId)) {
            newCategories.push(catId)
          }
        })
        return newCategories
      })
    }
  }

  // Update markers visibility based on selected categories
  const updateMarkersVisibility = () => {
    if (!mapLoaded || !markersRef.current.length) return

    markersRef.current.forEach((marker) => {
      const location = marker.locationData
      if (visibleCategories.includes(location.type)) {
        marker.addTo(mapInstanceRef.current)
      } else {
        marker.remove()
      }
    })
  }

  // Effect to handle highlighted location from chat
  useEffect(() => {
    if (highlightedLocation && mapLoaded && mapInstanceRef.current) {
      const location = luxuryLocations.find((loc) => loc.name.toLowerCase() === highlightedLocation.toLowerCase())
      if (location) {
        focusOnLocation(location)
      }
    }
  }, [highlightedLocation, mapLoaded])

  // Effect to update markers when visible categories change
  useEffect(() => {
    updateMarkersVisibility()
  }, [visibleCategories])

  useEffect(() => {
    // Add Leaflet CSS to head
    const addLeafletCSS = () => {
      const link = document.createElement("link")
      link.rel = "stylesheet"
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      link.integrity = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
      link.crossOrigin = ""
      document.head.appendChild(link)
      return link
    }

    // Initialize map
    const initializeMap = async () => {
      try {
        // Add CSS first
        const cssLink = addLeafletCSS()

        // Wait a moment for CSS to load
        await new Promise((resolve) => setTimeout(resolve, 300))

        // Import Leaflet dynamically
        const L = await import("leaflet")

        // Check if component is still mounted and ref exists
        if (!mapRef.current) {
          console.warn("Map container not found")
          return
        }

        // Create map instance
        const map = L.map(mapRef.current).setView([13.1939, -59.5432], 11)
        mapInstanceRef.current = map

        // Add satellite tile layer
        L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
          attribution:
            "Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community",
        }).addTo(map)

        // Add a semi-transparent layer with place names
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          opacity: 0.3,
        }).addTo(map)

        // Function to create a marker for a location
        const createMarker = (location: (typeof luxuryLocations)[0]) => {
          // Choose icon color based on location type
          let iconColor
          const category = categories.find((cat) => cat.id === location.type)
          iconColor = category?.color.replace("bg-", "") || "#000000"

          // Convert Tailwind color classes to hex colors
          switch (iconColor) {
            case "blue-500":
              iconColor = "#3b82f6"
              break
            case "red-500":
              iconColor = "#ef4444"
              break
            case "purple-500":
              iconColor = "#a855f7"
              break
            case "yellow-500":
              iconColor = "#eab308"
              break
            case "green-500":
              iconColor = "#22c55e"
              break
            case "sky-500":
              iconColor = "#0ea5e9"
              break
            case "gray-500":
              iconColor = "#6b7280"
              break
            case "rose-600":
              iconColor = "#e11d48"
              break
            case "pink-500":
              iconColor = "#ec4899"
              break
            case "indigo-600":
              iconColor = "#4f46e5"
              break
            case "emerald-600":
              iconColor = "#059669"
              break
            case "teal-500":
              iconColor = "#14b8a6"
              break
            case "amber-600":
              iconColor = "#d97706"
              break
            default:
              iconColor = "#000000"
          }

          // Create a pin marker icon
          const locationIcon = L.divIcon({
            className: "custom-pin-marker",
            html: `
              <div class="pin-container">
                <div class="pin" style="background-color: ${iconColor};">
                  <div class="pin-inner"></div>
                </div>
                <div class="pin-shadow"></div>
              </div>
            `,
            iconSize: [30, 42],
            iconAnchor: [15, 42],
            popupAnchor: [0, -40],
          })

          // Create popup content with more details
          let popupContent = `
            <div class="p-0 luxury-popup">
              <div class="luxury-popup-header" style="background: linear-gradient(to right, ${iconColor}, rgba(0,0,0,0.8));">
                <h3 class="luxury-popup-title">${location.name}</h3>
                ${
                  location.rating
                    ? `<div class="luxury-popup-rating">${"★".repeat(Math.floor(location.rating))}${
                        location.rating % 1 === 0.5 ? "½" : ""
                      }</div>`
                    : ""
                }
              </div>
              <div class="luxury-popup-content">
                <p class="luxury-popup-description">${location.description}</p>
                <div class="luxury-popup-details">
          `

          // Add price range if available
          if (location.priceRange) {
            popupContent += `
              <div class="luxury-popup-detail">
                <span class="luxury-popup-icon">💰</span>
                <span>Price: ${location.priceRange}</span>
              </div>
            `
          }

          // Add phone if available
          if (location.phone) {
            popupContent += `
              <div class="luxury-popup-detail">
                <span class="luxury-popup-icon">📞</span>
                <span>${location.phone}</span>
              </div>
            `
          }

          // Add amenities if available
          if (location.amenities && location.amenities.length > 0) {
            popupContent += `
              <div class="luxury-popup-detail">
                <span class="luxury-popup-icon">✨</span>
                <span>${location.amenities.join(" • ")}</span>
              </div>
            `
          }

          popupContent += `</div>` // Close luxury-popup-details

          // Add website if available
          if (location.website) {
            popupContent += `
              <div class="luxury-popup-website">
                <a href="${location.website}" target="_blank" class="luxury-popup-button">Visit Website</a>
              </div>
            `
          }

          popupContent += `
              </div>
            </div>
          `

          const marker = L.marker(location.position as [number, number], { icon: locationIcon })

          marker.bindPopup(popupContent, {
            maxWidth: 300,
            className: "luxury-popup-container",
          })

          // Store the reference to the original location for later use
          marker.locationData = location

          // Add to map if the category is visible
          if (visibleCategories.includes(location.type)) {
            marker.addTo(map)
          }

          return marker
        }

        // Create markers for all locations
        const allMarkers = luxuryLocations.map((location) => createMarker(location))
        markersRef.current = allMarkers

        // Add custom CSS for popups
        const style = document.createElement("style")
        style.textContent = `
          .luxury-popup-container .leaflet-popup-content-wrapper {
            padding: 0;
            overflow: hidden;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
          }
          .luxury-popup-container .leaflet-popup-content {
            margin: 0;
            width: 300px !important;
          }
          .luxury-popup-header {
            padding: 12px 15px;
            color: white;
            position: relative;
          }
          .luxury-popup-title {
            font-size: 16px;
            font-weight: bold;
            margin: 0;
          }
          .luxury-popup-rating {
            position: absolute;
            top: 12px;
            right: 15px;
            color: gold;
            font-size: 14px;
          }
          .luxury-popup-content {
            padding: 15px;
            background: white;
            color: #333;
          }
          .luxury-popup-description {
            margin: 0 0 12px 0;
            font-size: 13px;
            line-height: 1.4;
          }
          .luxury-popup-details {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 12px;
          }
          .luxury-popup-detail {
            display: flex;
            align-items: center;
            font-size: 12px;
          }
          .luxury-popup-icon {
            margin-right: 8px;
            font-size: 14px;
          }
          .luxury-popup-website {
            text-align: center;
          }
          .luxury-popup-button {
            display: inline-block;
            padding: 8px 16px;
            background: #38bdf8;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 13px;
            font-weight: bold;
            transition: background 0.2s;
          }
          .luxury-popup-button:hover {
            background: #0ea5e9;
          }
          
          /* Pin marker styling */
          .custom-pin-marker {
            background: transparent;
            border: none;
          }
          
          .pin-container {
            position: relative;
            width: 30px;
            height: 42px;
          }
          
          .pin {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 20px;
            height: 20px;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            animation: bounce 0.5s ease-out;
            z-index: 1;
          }
          
          .pin-inner {
            position: absolute;
            width: 10px;
            height: 10px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
          }
          
          .pin-shadow {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 14px;
            height: 3px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 50%;
            z-index: 0;
          }
          
          @keyframes bounce {
            0% {
              transform: rotate(-45deg) translateY(-20px);
              opacity: 0;
            }
            60% {
              transform: rotate(-45deg) translateY(5px);
            }
            100% {
              transform: rotate(-45deg) translateY(0);
              opacity: 1;
            }
          }
          
          .pin:hover {
            transform: rotate(-45deg) scale(1.2);
            z-index: 10;
          }
        `
        document.head.appendChild(style)

        setMapLoaded(true)
      } catch (error) {
        console.error("Error initializing map:", error)
        setLoadError(true)
      }
    }

    initializeMap()

    // Cleanup function
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  // Show static map if there's an error loading Leaflet
  if (loadError) {
    return <StaticMap />
  }

  // Render stars for rating
  const renderRatingStars = (rating: number) => {
    const fullStars = Math.floor(rating)
    const hasHalfStar = rating % 1 >= 0.5

    return (
      <div className="flex items-center">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
        ))}
        {hasHalfStar && (
          <div className="relative h-3 w-3">
            <Star className="absolute h-3 w-3 text-yellow-400" />
            <div className="absolute h-3 w-1.5 overflow-hidden">
              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            </div>
          </div>
        )}
        {[...Array(5 - fullStars - (hasHalfStar ? 1 : 0))].map((_, i) => (
          <Star key={`empty-${i}`} className="h-3 w-3 text-yellow-400" />
        ))}
      </div>
    )
  }

  return (
    <div className="h-full relative flex flex-col">
      {/* Search and filter bar */}
      <div className="p-3 bg-gray-900/90 border-b border-platinum/30 z-10 flex items-center gap-2">
        <div className="flex-1 flex gap-2">
          <Input
            placeholder="Search for locations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-gray-800 border-platinum/30 text-white"
          />
          <Button onClick={handleSearch} className="bg-platinum hover:bg-platinum/80 text-black">
            <Search className="h-4 w-4" />
          </Button>
        </div>

        {/* Category filter dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="bg-gray-800 border-platinum/30 text-platinum">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-gray-900 border-platinum/30 text-platinum">
            {categoryGroups.map((group) => (
              <div key={group.id} className="px-2 py-1.5">
                <div className="mb-1">
                  <DropdownMenuCheckboxItem
                    checked={group.categories.every((catId) => visibleCategories.includes(catId))}
                    onCheckedChange={() => toggleCategoryGroup(group.id)}
                    className="font-semibold"
                  >
                    {group.name}
                  </DropdownMenuCheckboxItem>
                </div>
                <div className="ml-4 space-y-1">
                  {group.categories.map((catId) => {
                    const category = categories.find((c) => c.id === catId)
                    if (!category) return null

                    return (
                      <DropdownMenuCheckboxItem
                        key={catId}
                        checked={visibleCategories.includes(catId)}
                        onCheckedChange={() => toggleCategory(catId)}
                        className="text-sm"
                      >
                        {category.name}
                      </DropdownMenuCheckboxItem>
                    )
                  })}
                </div>
              </div>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Search results */}
      {searchResults.length > 0 && (
        <div className="absolute top-16 left-3 right-3 z-[1000] bg-gray-800/90 rounded border border-platinum/30 max-h-[200px] overflow-y-auto">
          {searchResults.map((location, index) => (
            <div
              key={index}
              className="p-2 hover:bg-gray-700/50 cursor-pointer border-b border-platinum/10 last:border-0"
              onClick={() => focusOnLocation(location)}
            >
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-platinum/70" />
                <div>
                  <p className="text-sm font-medium text-platinum">{location.name}</p>
                  <p className="text-xs text-platinum/70">{location.type}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Map container */}
      <div ref={mapRef} className="flex-1" />

      {/* Loading indicator */}
      {!mapLoaded && !loadError && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-800 text-platinum/70 z-10">
          <div className="text-center">
            <div className="mb-4 animate-pulse">
              <div className="h-16 w-16 mx-auto rounded-full bg-platinum/20"></div>
            </div>
            <p>Loading satellite view of Barbados...</p>
          </div>
        </div>
      )}

      {/* Map legend */}
      <div className="absolute bottom-4 left-4 z-[1000]">
        <Card className="bg-gray-900/80 border-platinum/30 p-2 max-w-[200px] text-xs">
          <div className="font-semibold text-platinum mb-1">Map Legend</div>
          <div className="grid grid-cols-2 gap-x-2 gap-y-1">
            {categories
              .filter((cat) => visibleCategories.includes(cat.id))
              .map((category) => {
                const color = category.color.replace("bg-", "")
                return (
                  <div key={category.id} className="flex items-center">
                    <div className={`w-3 h-3 rounded-full ${category.color} mr-1`}></div>
                    <span className="text-platinum/80 truncate">{category.name}</span>
                  </div>
                )
              })}
          </div>
        </Card>
      </div>

      {/* Selected location info */}
      {selectedLocation && (
        <Card className="absolute bottom-4 right-4 z-[1000] bg-gray-900/90 border-platinum/30 p-0 max-w-[300px] text-xs text-platinum/80 overflow-hidden">
          <div className="bg-gradient-to-r from-gray-800 to-gray-900 p-3 border-b border-platinum/20">
            <div className="flex justify-between items-start">
              <h3 className="font-semibold text-platinum text-sm">{selectedLocation.name}</h3>
              {selectedLocation.rating && renderRatingStars(selectedLocation.rating)}
            </div>
            <div className="flex items-center mt-1">
              <Badge
                variant="outline"
                className={`text-[10px] bg-gray-800/50 ${selectedLocation.essential ? "text-rose-400" : "text-platinum/70"} border-platinum/20`}
              >
                {selectedLocation.type}
              </Badge>
              {selectedLocation.priceRange && (
                <span className="ml-2 text-[10px] text-platinum/70">{selectedLocation.priceRange}</span>
              )}
            </div>
          </div>

          <div className="p-3">
            <p className="mb-3 text-platinum/90 leading-tight">{selectedLocation.description}</p>

            {selectedLocation.amenities && (
              <div className="mb-3">
                <h4 className="text-[11px] font-medium text-platinum/80 mb-1">Amenities</h4>
                <div className="flex flex-wrap gap-1">
                  {selectedLocation.amenities.map((amenity, index) => (
                    <Badge key={index} variant="secondary" className="text-[9px] bg-gray-800/70">
                      {amenity}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2">
              {selectedLocation.phone && (
                <div className="flex items-center text-[11px] text-platinum/80">
                  <Phone className="h-3 w-3 mr-2 text-platinum/60" />
                  {selectedLocation.phone}
                </div>
              )}

              {selectedLocation.website && (
                <a
                  href={selectedLocation.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-[11px] text-platinum hover:text-platinum/100 transition-colors"
                >
                  <Globe className="h-3 w-3 mr-2 text-platinum/60" />
                  Visit Website
                </a>
              )}
            </div>
          </div>

          <div className="p-2 bg-gray-800/50 border-t border-platinum/20 flex justify-end">
            <Button
              size="sm"
              className="bg-platinum/20 hover:bg-platinum/30 text-platinum text-[10px] h-7"
              onClick={() => mapInstanceRef.current?.setView(selectedLocation.position, 16)}
            >
              <Navigation className="h-3 w-3 mr-1" />
              Navigate
            </Button>
          </div>
        </Card>
      )}
    </div>
  )
}
