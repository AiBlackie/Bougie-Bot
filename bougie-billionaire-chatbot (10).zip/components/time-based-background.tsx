"use client"

import type React from "react"
import { useEffect, useState } from "react"

export function TimeBasedBackground({ children }: { children: React.ReactNode }) {
  const [timeOfDay, setTimeOfDay] = useState<"morning" | "day" | "evening" | "night">("day")

  useEffect(() => {
    // Function to get Barbados time and determine time of day
    const updateTimeOfDay = () => {
      // Create a new date object using the current time
      const now = new Date()

      // Get the UTC time in milliseconds
      const utcTime = now.getTime() + now.getTimezoneOffset() * 60000

      // Barbados is UTC-4, so we subtract 4 hours
      const barbadosTime = new Date(utcTime - 4 * 60 * 60 * 1000)

      // Get hours in 24-hour format
      const hours = barbadosTime.getHours()

      // Determine time of day
      if (hours >= 5 && hours < 10) {
        setTimeOfDay("morning")
      } else if (hours >= 10 && hours < 17) {
        setTimeOfDay("day")
      } else if (hours >= 17 && hours < 20) {
        setTimeOfDay("evening")
      } else {
        setTimeOfDay("night")
      }
    }

    // Update immediately and then every minute
    updateTimeOfDay()
    const interval = setInterval(updateTimeOfDay, 60000)

    return () => clearInterval(interval)
  }, [])

  // Define background styles based on time of day
  const getBackgroundStyle = () => {
    switch (timeOfDay) {
      case "morning":
        return "bg-gradient-to-b from-orange-500 via-amber-300 to-sky-700"
      case "day":
        return "bg-gradient-to-b from-sky-500 via-sky-400 to-sky-700"
      case "evening":
        return "bg-gradient-to-b from-orange-600 via-purple-500 to-indigo-900"
      case "night":
        return "bg-gradient-to-b from-gray-900 to-black"
      default:
        return "bg-gradient-to-b from-gray-900 to-black"
    }
  }

  // Get cloud opacity based on time of day
  const getCloudOpacity = () => {
    switch (timeOfDay) {
      case "morning":
        return "opacity-70"
      case "day":
        return "opacity-60"
      case "evening":
        return "opacity-50"
      case "night":
        return "opacity-30"
      default:
        return "opacity-60"
    }
  }

  // Get cloud color based on time of day
  const getCloudColor = () => {
    switch (timeOfDay) {
      case "morning":
        return "text-white"
      case "day":
        return "text-white"
      case "evening":
        return "text-gray-200"
      case "night":
        return "text-gray-700"
      default:
        return "text-white"
    }
  }

  return (
    <div className={`min-h-screen flex flex-col items-center transition-colors duration-1000 ${getBackgroundStyle()}`}>
      <div className="absolute inset-0 bg-black/40 z-0"></div>

      {/* Cloud layer */}
      <div className="absolute inset-0 overflow-hidden z-0 pointer-events-none">
        {/* Large slow-moving background clouds */}
        <div className={`cloud cloud-1 ${getCloudOpacity()} ${getCloudColor()}`}></div>
        <div className={`cloud cloud-2 ${getCloudOpacity()} ${getCloudColor()}`}></div>
        <div className={`cloud cloud-3 ${getCloudOpacity()} ${getCloudColor()}`}></div>

        {/* Medium-sized clouds */}
        <div className={`cloud cloud-4 ${getCloudOpacity()} ${getCloudColor()}`}></div>
        <div className={`cloud cloud-5 ${getCloudOpacity()} ${getCloudColor()}`}></div>

        {/* Small faster-moving foreground clouds */}
        <div className={`cloud cloud-6 ${getCloudOpacity()} ${getCloudColor()}`}></div>
        <div className={`cloud cloud-7 ${getCloudOpacity()} ${getCloudColor()}`}></div>
      </div>

      <div className="relative z-10 w-full">{children}</div>
    </div>
  )
}
