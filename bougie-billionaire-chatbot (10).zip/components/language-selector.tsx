"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Check, ChevronDown, Globe, Lock } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { SubscriptionManager, type SubscriptionTier, type SubscriptionPlan } from "@/components/subscription-manager"

export interface Language {
  code: string
  name: string
  nativeName: string
  flag: string
  premium: boolean
}

interface LanguageSelectorProps {
  selectedLanguage: string
  onLanguageChange: (languageCode: string) => void
  subscription: SubscriptionTier
  onUpgradeSubscription: (plan: SubscriptionPlan) => Promise<boolean>
}

export function LanguageSelector({
  selectedLanguage,
  onLanguageChange,
  subscription,
  onUpgradeSubscription,
}: LanguageSelectorProps) {
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false)

  // Available languages with premium status
  const languages: Language[] = [
    { code: "en", name: "English", nativeName: "English", flag: "🇬🇧", premium: false },
    { code: "fr", name: "French", nativeName: "Français", flag: "🇫🇷", premium: true },
    { code: "es", name: "Spanish", nativeName: "Español", flag: "🇪🇸", premium: true },
    { code: "de", name: "German", nativeName: "Deutsch", flag: "🇩🇪", premium: true },
    { code: "pt", name: "Portuguese", nativeName: "Português", flag: "🇵🇹", premium: true },
    { code: "it", name: "Italian", nativeName: "Italiano", flag: "🇮🇹", premium: true },
    { code: "zh", name: "Chinese", nativeName: "中文", flag: "🇨🇳", premium: true },
    { code: "ja", name: "Japanese", nativeName: "日本語", flag: "🇯🇵", premium: true },
    { code: "ar", name: "Arabic", nativeName: "العربية", flag: "🇦🇪", premium: true },
  ]

  // Get the current language object
  const currentLanguage = languages.find((lang) => lang.code === selectedLanguage) || languages[0]

  // Check if user can access a language based on their subscription
  const canAccessLanguage = (language: Language) => {
    if (!language.premium) return true // Free languages are accessible to all
    if (subscription === "premium") return true // Premium subscribers can access all languages

    // Basic subscribers can access English plus one premium language
    if (subscription === "basic") {
      // If they've already selected a premium language, they can only access that one
      const selectedPremiumLanguage = languages.find((lang) => lang.code === selectedLanguage && lang.premium)

      // If they haven't selected a premium language yet, they can select any one
      if (!selectedPremiumLanguage) return true

      // If this is their already selected premium language, they can access it
      return language.code === selectedLanguage
    }

    // Free users can't access premium languages
    return false
  }

  const handleLanguageSelect = (language: Language) => {
    if (canAccessLanguage(language)) {
      onLanguageChange(language.code)
    } else {
      setShowUpgradeDialog(true)
    }
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="bg-gray-800/90 border-platinum/30 text-platinum">
            <Globe className="h-4 w-4 mr-2" />
            <span className="mr-1">{currentLanguage.flag}</span>
            {currentLanguage.name}
            <ChevronDown className="h-4 w-4 ml-2" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="bg-gray-900 border-platinum/30 text-platinum">
          {languages.map((language) => {
            const isAccessible = canAccessLanguage(language)
            const isSelected = language.code === selectedLanguage

            return (
              <DropdownMenuItem
                key={language.code}
                className={`flex items-center justify-between ${
                  isSelected ? "bg-gray-800" : ""
                } ${!isAccessible ? "opacity-70" : ""}`}
                onClick={() => handleLanguageSelect(language)}
              >
                <div className="flex items-center">
                  <span className="mr-2">{language.flag}</span>
                  <span>{language.name}</span>
                  <span className="ml-1 text-xs text-platinum/60">({language.nativeName})</span>
                </div>
                <div className="flex items-center">
                  {isSelected && <Check className="h-4 w-4 text-green-400 mr-1" />}
                  {language.premium && !isAccessible && <Lock className="h-3 w-3 text-platinum/60" />}
                  {language.premium && (
                    <Badge
                      variant="outline"
                      className="ml-2 text-[10px] bg-gray-800/50 border-platinum/20 text-platinum/70"
                    >
                      Premium
                    </Badge>
                  )}
                </div>
              </DropdownMenuItem>
            )
          })}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="bg-gray-900 border-platinum/30 text-platinum max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">Upgrade to Access Premium Languages</DialogTitle>
            <DialogDescription className="text-platinum/70">
              Unlock multilingual capabilities for your luxury Barbados concierge experience
            </DialogDescription>
          </DialogHeader>

          <SubscriptionManager
            currentTier={subscription}
            onSubscribe={onUpgradeSubscription}
            onClose={() => setShowUpgradeDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  )
}
