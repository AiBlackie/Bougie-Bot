import type React from "react"

interface MessageBubbleProps {
  content: string
  isUser: boolean
  renderContent?: () => React.ReactNode
}

export function MessageBubble({ content, isUser, renderContent }: MessageBubbleProps) {
  return (
    <div
      className={`message-bubble relative rounded-lg p-3 ${
        isUser
          ? "user bg-gradient-to-br from-sky-800 to-indigo-900 text-white border border-sky-500/30"
          : "bg-gray-800/90 text-white border border-platinum/30"
      }`}
    >
      {renderContent ? renderContent() : content}
      <div className="sparkle-star sparkle-1"></div>
      <div className="sparkle-star sparkle-2"></div>
      <div className="sparkle-star sparkle-3"></div>
      <div className="sparkle-star sparkle-4"></div>
      <div className="sparkle-star sparkle-5"></div>
    </div>
  )
}
