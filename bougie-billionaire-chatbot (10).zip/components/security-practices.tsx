import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Lock, Eye, FileText, Server, CreditCard } from "lucide-react"

export function SecurityPractices() {
  return (
    <Card className="bg-gray-900/70 border-platinum/30">
      <CardHeader>
        <CardTitle className="text-platinum flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Our Security Commitment
        </CardTitle>
        <CardDescription className="text-platinum/70">
          How we protect your personal and financial information
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
            <div className="flex items-start gap-2">
              <Lock className="h-4 w-4 text-platinum/70 mt-1" />
              <div>
                <h3 className="text-sm font-medium text-platinum">Secure Data Handling</h3>
                <p className="text-xs text-platinum/70 mt-1">
                  We never collect sensitive financial information directly. All payments are processed through
                  PCI-compliant secure payment platforms.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
            <div className="flex items-start gap-2">
              <Eye className="h-4 w-4 text-platinum/70 mt-1" />
              <div>
                <h3 className="text-sm font-medium text-platinum">Privacy Protection</h3>
                <p className="text-xs text-platinum/70 mt-1">
                  Your personal information is only used for the specific services you request. We never share your data
                  with third parties without your explicit consent.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
            <div className="flex items-start gap-2">
              <FileText className="h-4 w-4 text-platinum/70 mt-1" />
              <div>
                <h3 className="text-sm font-medium text-platinum">Transparent Practices</h3>
                <p className="text-xs text-platinum/70 mt-1">
                  Our privacy policy clearly outlines how we collect, use, and protect your information. We're committed
                  to transparency in all our operations.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/50 p-3 rounded border border-platinum/20">
            <div className="flex items-start gap-2">
              <Server className="h-4 w-4 text-platinum/70 mt-1" />
              <div>
                <h3 className="text-sm font-medium text-platinum">Secure Infrastructure</h3>
                <p className="text-xs text-platinum/70 mt-1">
                  Our systems employ industry-leading encryption, regular security audits, and strict access controls to
                  safeguard your data.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800/50 p-3 rounded border border-platinum/20 md:col-span-2">
            <div className="flex items-start gap-2">
              <CreditCard className="h-4 w-4 text-platinum/70 mt-1" />
              <div>
                <h3 className="text-sm font-medium text-platinum">Secure Payment Processing</h3>
                <p className="text-xs text-platinum/70 mt-1">
                  All financial transactions are handled through dedicated secure payment gateways that meet the highest
                  security standards in the industry. We never store your complete credit card information on our
                  servers.
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
