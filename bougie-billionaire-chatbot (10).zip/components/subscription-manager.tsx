"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Check, Lock, ExternalLink, AlertCircle, Mail, User, MessageSquare, CheckCircle, Shield } from "lucide-react"

export type SubscriptionTier = "free" | "basic" | "premium"

export interface SubscriptionPlan {
  id: string
  name: string
  description: string
  price: number
  features: string[]
  languages: string[]
  tier: SubscriptionTier
  recommended?: boolean
}

interface SubscriptionManagerProps {
  currentTier: SubscriptionTier
  onSubscribe: (plan: SubscriptionPlan) => Promise<boolean>
  onClose: () => void
  userId?: string
}

export function SubscriptionManager({ currentTier, onSubscribe, onClose, userId = "" }: SubscriptionManagerProps) {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showContactDialog, setShowContactDialog] = useState(false)
  const [showSecureRedirectDialog, setShowSecureRedirectDialog] = useState(false)
  const [contactInfo, setContactInfo] = useState({
    email: "",
    name: "",
    notes: "",
  })
  const [contactSubmitted, setContactSubmitted] = useState(false)

  const subscriptionPlans: SubscriptionPlan[] = [
    {
      id: "free",
      name: "Free",
      description: "Basic Barbados concierge services in English only",
      price: 0,
      features: [
        "Luxury hotel recommendations",
        "Restaurant information",
        "Basic activity suggestions",
        "English language only",
      ],
      languages: ["English"],
      tier: "free",
    },
    {
      id: "basic",
      name: "Language Plus",
      description: "All free features plus access to one additional language",
      price: 9.99,
      features: [
        "All Free tier features",
        "Choose one additional language",
        "Personalized recommendations",
        "Priority response time",
      ],
      languages: ["English", "Choose one: French, Spanish, German, Portuguese, Italian"],
      tier: "basic",
      recommended: true,
    },
    {
      id: "premium",
      name: "Global Luxury",
      description: "Full multilingual support with all premium features",
      price: 19.99,
      features: [
        "All Language Plus features",
        "Access to all supported languages",
        "VIP concierge services",
        "Custom itinerary planning",
        "24/7 priority support",
      ],
      languages: ["English", "French", "Spanish", "German", "Portuguese", "Italian", "Chinese", "Japanese", "Arabic"],
      tier: "premium",
    },
  ]

  const handleContactSubmit = async () => {
    if (!contactInfo.email || !selectedPlan) {
      setError("Email address is required")
      return
    }

    setIsProcessing(true)
    setError(null)

    try {
      // Send upgrade request to backend
      const response = await fetch("/api/upgrade-request", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: contactInfo.email,
          name: contactInfo.name,
          currentTier,
          requestedTier: selectedPlan.tier,
          userId,
          additionalNotes: contactInfo.notes,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to submit upgrade request")
      }

      setContactSubmitted(true)
    } catch (err) {
      setError("Failed to submit your request. Please try again.")
      console.error("Contact submission error:", err)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleSecureRedirect = () => {
    // In a real application, this would redirect to a secure payment processor
    // like Stripe, PayPal, etc. with proper encryption and PCI compliance
    setShowSecureRedirectDialog(false)

    // Simulate successful upgrade for demo purposes
    setTimeout(() => {
      onSubscribe(selectedPlan!)
    }, 1000)
  }

  const openPaymentDialog = (plan: SubscriptionPlan) => {
    if (plan.tier === "free" || plan.tier === currentTier) {
      return // Don't show payment for free plan or current tier
    }

    setSelectedPlan(plan)

    // For security, we'll collect only email first, then redirect to secure payment
    setShowContactDialog(true)
  }

  return (
    <div className="w-full max-w-5xl mx-auto">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-platinum mb-2">Upgrade Your Bougie Experience</h2>
        <p className="text-platinum/70">
          Unlock multilingual capabilities and premium features for your luxury Barbados concierge
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {subscriptionPlans.map((plan) => (
          <Card
            key={plan.id}
            className={`bg-gray-900/90 border-platinum/30 relative overflow-hidden ${
              plan.recommended ? "ring-2 ring-platinum" : ""
            }`}
          >
            {plan.recommended && (
              <div className="absolute top-0 right-0">
                <Badge className="bg-platinum text-black m-2">Recommended</Badge>
              </div>
            )}

            <CardHeader>
              <CardTitle className="text-platinum flex items-center justify-between">
                {plan.name}
                {plan.tier === currentTier && <Badge className="bg-green-600 text-white">Current Plan</Badge>}
              </CardTitle>
              <div className="flex items-baseline mt-2">
                <span className="text-3xl font-bold text-platinum">${plan.price}</span>
                <span className="text-sm text-platinum/70 ml-1">/month</span>
              </div>
              <CardDescription className="text-platinum/70 mt-2">{plan.description}</CardDescription>
            </CardHeader>

            <CardContent>
              <h4 className="font-medium text-platinum mb-2">Features:</h4>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-platinum/80">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-4">
                <h4 className="font-medium text-platinum mb-2">Languages:</h4>
                <div className="flex flex-wrap gap-1">
                  {plan.languages.map((language, index) => (
                    <Badge key={index} variant="outline" className="bg-gray-800/50 text-platinum/90 border-platinum/20">
                      {language}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>

            <CardFooter>
              <Button
                className={`w-full ${
                  plan.tier === "free"
                    ? "bg-gray-700 hover:bg-gray-600 text-platinum"
                    : "bg-platinum hover:bg-platinum/80 text-black"
                }`}
                onClick={() => openPaymentDialog(plan)}
                disabled={plan.tier === currentTier}
              >
                {plan.tier === currentTier ? "Current Plan" : plan.tier === "free" ? "Free Plan" : "Subscribe"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Contact Information Dialog - Only collects email, no sensitive data */}
      <Dialog open={showContactDialog} onOpenChange={setShowContactDialog}>
        <DialogContent className="bg-gray-900 border-platinum/30 text-platinum">
          <DialogHeader>
            <DialogTitle>Request {selectedPlan?.name} Subscription</DialogTitle>
            <DialogDescription className="text-platinum/70">
              {contactSubmitted
                ? "Thank you for your interest! We've sent a confirmation to your email."
                : "Provide your contact information and we'll help you upgrade"}
            </DialogDescription>
          </DialogHeader>

          {!contactSubmitted ? (
            <>
              <div className="space-y-4 py-4">
                {error && (
                  <div className="p-3 bg-red-900/30 border border-red-500/50 rounded-lg text-sm flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 text-red-400 mt-0.5" />
                    <p className="text-red-200">{error}</p>
                  </div>
                )}

                <div className="bg-gray-800/50 p-4 rounded-lg border border-platinum/20">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-platinum/80">Subscription</span>
                    <span className="font-medium text-platinum">{selectedPlan?.name}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-platinum/80">Price</span>
                    <span className="font-medium text-platinum">${selectedPlan?.price}/month</span>
                  </div>
                </div>

                <div className="p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg mb-4 flex items-start gap-2">
                  <Shield className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-blue-300 font-medium">Your Security is Our Priority</p>
                    <p className="text-xs text-blue-300/80 mt-1">
                      We only collect your email here. For payment processing, you'll be redirected to our secure
                      payment platform that meets the highest security standards for financial transactions.
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="space-y-1">
                    <Label htmlFor="email" className="text-platinum/90 flex items-center gap-1">
                      Email Address <span className="text-red-400">*</span>
                    </Label>
                    <div className="flex items-center bg-gray-800 border border-platinum/30 rounded-md overflow-hidden">
                      <div className="px-3 py-2 bg-gray-800/70">
                        <Mail className="h-4 w-4 text-platinum/50" />
                      </div>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={contactInfo.email}
                        onChange={(e) => setContactInfo({ ...contactInfo, email: e.target.value })}
                        className="bg-transparent border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="name" className="text-platinum/90 flex items-center gap-1">
                      Your Name <span className="text-platinum/50">(Optional)</span>
                    </Label>
                    <div className="flex items-center bg-gray-800 border border-platinum/30 rounded-md overflow-hidden">
                      <div className="px-3 py-2 bg-gray-800/70">
                        <User className="h-4 w-4 text-platinum/50" />
                      </div>
                      <Input
                        id="name"
                        type="text"
                        placeholder="John Doe"
                        value={contactInfo.name}
                        onChange={(e) => setContactInfo({ ...contactInfo, name: e.target.value })}
                        className="bg-transparent border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="notes" className="text-platinum/90 flex items-center gap-1">
                      Additional Notes <span className="text-platinum/50">(Optional)</span>
                    </Label>
                    <div className="flex bg-gray-800 border border-platinum/30 rounded-md overflow-hidden">
                      <div className="px-3 py-2 bg-gray-800/70">
                        <MessageSquare className="h-4 w-4 text-platinum/50" />
                      </div>
                      <Textarea
                        id="notes"
                        placeholder="Any specific requirements or questions..."
                        value={contactInfo.notes}
                        onChange={(e) => setContactInfo({ ...contactInfo, notes: e.target.value })}
                        className="bg-transparent border-0 focus-visible:ring-0 focus-visible:ring-offset-0 min-h-[80px]"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-platinum/60 mt-2">
                  <Lock className="h-3 w-3" />
                  <span>Your contact information is secure and will only be used to process your subscription</span>
                </div>
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowContactDialog(false)}
                  className="border-platinum/30 text-platinum hover:bg-gray-800"
                  disabled={isProcessing}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleContactSubmit}
                  className="bg-platinum hover:bg-platinum/80 text-black"
                  disabled={isProcessing || !contactInfo.email}
                >
                  {isProcessing ? (
                    <>
                      <div className="h-4 w-4 border-2 border-black border-t-transparent rounded-full animate-spin mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>Request Upgrade</>
                  )}
                </Button>
              </DialogFooter>
            </>
          ) : (
            <div className="py-6 text-center">
              <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4 mb-4">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-2" />
                <p className="text-green-300">Your upgrade request has been submitted successfully!</p>
              </div>
              <p className="text-platinum/80 mb-4">
                Thank you for your interest in the {selectedPlan?.name} plan. We've sent a confirmation email to{" "}
                <span className="text-platinum font-medium">{contactInfo.email}</span> with next steps.
              </p>
              <p className="text-platinum/80 mb-4">
                Our team will contact you shortly to complete your subscription through our secure payment platform.
              </p>
              <Button
                onClick={() => {
                  setShowContactDialog(false)
                  setContactSubmitted(false)
                  setContactInfo({ email: "", name: "", notes: "" })
                }}
                className="bg-platinum hover:bg-platinum/80 text-black"
              >
                Close
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Secure Redirect Dialog - For demonstration purposes */}
      <Dialog open={showSecureRedirectDialog} onOpenChange={setShowSecureRedirectDialog}>
        <DialogContent className="bg-gray-900 border-platinum/30 text-platinum">
          <DialogHeader>
            <DialogTitle>Secure Payment Redirect</DialogTitle>
            <DialogDescription className="text-platinum/70">
              You will be redirected to our secure payment platform
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="p-4 bg-gray-800/50 rounded-lg border border-platinum/20">
              <div className="flex items-center justify-center mb-4">
                <Lock className="h-12 w-12 text-platinum/50" />
              </div>
              <p className="text-center text-platinum/80 mb-2">
                For your security, we process all payments through our secure payment platform.
              </p>
              <p className="text-center text-platinum/80">
                You will be redirected to complete your {selectedPlan?.name} subscription purchase.
              </p>
            </div>

            <div className="p-3 bg-green-900/20 border border-green-500/30 rounded-lg flex items-start gap-2">
              <Shield className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm text-green-300 font-medium">Secure Transaction</p>
                <p className="text-xs text-green-300/80 mt-1">
                  Our payment platform uses bank-level encryption and complies with PCI DSS standards to ensure your
                  financial information is always protected.
                </p>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowSecureRedirectDialog(false)}
              className="border-platinum/30 text-platinum hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button onClick={handleSecureRedirect} className="bg-platinum hover:bg-platinum/80 text-black">
              <ExternalLink className="h-4 w-4 mr-2" />
              Continue to Secure Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
