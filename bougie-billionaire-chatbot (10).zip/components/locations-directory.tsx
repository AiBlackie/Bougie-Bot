"use client"

import React from "react"
import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Star,
  Globe,
  MapPin,
  Hotel,
  Utensils,
  Landmark,
  Umbrella,
  ShoppingBag,
  Anchor,
  Map,
  Building2,
  Stethoscope,
  ShieldAlert,
  ShoppingCart,
  Pill,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  ChevronLeft,
  Church,
  Phone,
  Info,
} from "lucide-react"
import { luxuryLocations, categories, categoryGroups } from "@/data/locations"

interface LocationsDirectoryProps {
  selectedCategory: string
  onCategorySelect: (categoryId: string) => void
  onLocationSelect: (locationName: string) => void
}

export default function LocationsDirectory({
  selectedCategory,
  onCategorySelect,
  onLocationSelect,
}: LocationsDirectoryProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<typeof luxuryLocations>([])
  const [currentPage, setCurrentPage] = useState(1)
  const locationsPerPage = 8 // Increased from 4 to 8 for better use of space
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    luxury: true,
    essential: true,
  })
  const [expandedLocation, setExpandedLocation] = useState<string | null>(null)

  // Category pagination
  const [currentCategoryPage, setCurrentCategoryPage] = useState(1)
  const categoriesPerPage = 5 // Show only 5 categories at a time

  // Get filtered locations based on selected category
  const getFilteredLocations = () => {
    if (selectedCategory === "all") {
      return luxuryLocations
    }
    return luxuryLocations.filter((location) => location.type === selectedCategory)
  }

  // Pagination functions
  const nextPage = () => setCurrentPage((prev) => Math.min(prev + 1, totalPages))
  const prevPage = () => setCurrentPage((prev) => Math.max(prev - 1, 1))

  // Category pagination functions
  const nextCategoryPage = (groupId: string) => {
    const groupCategories = categoryGroups.find((g) => g.id === groupId)?.categories || []
    const totalPages = Math.ceil(groupCategories.length / categoriesPerPage)

    setCurrentCategoryPage((prev) => {
      if (prev < totalPages) return prev + 1
      return prev
    })
  }

  const prevCategoryPage = () => {
    setCurrentCategoryPage((prev) => {
      if (prev > 1) return prev - 1
      return prev
    })
  }

  // Handle search
  const handleSearch = () => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    const query = searchQuery.toLowerCase()
    const results = luxuryLocations.filter(
      (location) =>
        location.name.toLowerCase().includes(query) ||
        location.description.toLowerCase().includes(query) ||
        (location.type && location.type.toLowerCase().includes(query)),
    )

    setSearchResults(results)
  }

  // Toggle category group expansion
  const toggleCategoryGroup = (groupId: string) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }))

    // Reset category page when toggling groups
    setCurrentCategoryPage(1)
  }

  // Toggle location expansion
  const toggleLocationExpansion = (locationName: string) => {
    if (expandedLocation === locationName) {
      setExpandedLocation(null)
    } else {
      setExpandedLocation(locationName)
    }
  }

  // Render stars for rating
  const renderRatingStars = (rating: number) => {
    const fullStars = Math.floor(rating)
    const hasHalfStar = rating % 1 >= 0.5

    return (
      <div className="flex items-center">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
        ))}
        {hasHalfStar && (
          <div className="relative h-3 w-3">
            <Star className="absolute h-3 w-3 text-yellow-400" />
            <div className="absolute h-3 w-1.5 overflow-hidden">
              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            </div>
          </div>
        )}
        {[...Array(5 - fullStars - (hasHalfStar ? 1 : 0))].map((_, i) => (
          <Star key={`empty-${i}`} className="h-3 w-3 text-yellow-400" />
        ))}
      </div>
    )
  }

  // Get the current category object
  const currentCategory = categories.find((cat) => cat.id === selectedCategory) || categories[0]

  // Get filtered locations
  const filteredLocations = getFilteredLocations()

  // Calculate pagination
  const totalPages = Math.ceil(filteredLocations.length / locationsPerPage)
  const indexOfLastLocation = currentPage * locationsPerPage
  const indexOfFirstLocation = indexOfLastLocation - locationsPerPage
  const currentLocations = filteredLocations.slice(indexOfFirstLocation, indexOfLastLocation)

  // Get icon component for a category
  const getCategoryIcon = (categoryId: string) => {
    switch (categoryId) {
      case "hotel":
        return Hotel
      case "dining":
        return Utensils
      case "attraction":
        return Landmark
      case "beach":
        return Umbrella
      case "shopping":
        return ShoppingBag
      case "marina":
        return Anchor
      case "area":
        return MapPin
      case "hospital":
        return Building2
      case "clinic":
        return Stethoscope
      case "police":
        return ShieldAlert
      case "supermarket":
        return ShoppingCart
      case "pharmacy":
        return Pill
      case "church":
        return Church
      default:
        return Map
    }
  }

  // Get paginated categories for a group
  const getPaginatedCategories = (groupId: string) => {
    const group = categoryGroups.find((g) => g.id === groupId)
    if (!group) return []

    const start = (currentCategoryPage - 1) * categoriesPerPage
    const end = start + categoriesPerPage

    return group.categories.slice(start, end)
  }

  // Calculate total pages for a category group
  const getCategoryGroupPages = (groupId: string) => {
    const group = categoryGroups.find((g) => g.id === groupId)
    if (!group) return 1

    return Math.ceil(group.categories.length / categoriesPerPage)
  }

  useEffect(() => {
    setCurrentPage(1)
    setExpandedLocation(null)
  }, [selectedCategory])

  return (
    <div className="h-full flex flex-col">
      {/* Search bar */}
      <div className="p-3 bg-gray-900/90 border-b border-platinum/30 z-10">
        <div className="flex gap-2">
          <Input
            placeholder="Search for locations or services..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-gray-800 border-platinum/30 text-white"
          />
          <Button onClick={handleSearch} className="bg-platinum hover:bg-platinum/80 text-black">
            <Search className="h-4 w-4" />
          </Button>
        </div>

        {/* Search results */}
        {searchResults.length > 0 && (
          <div className="mt-2 bg-gray-800/90 rounded border border-platinum/30 max-h-[150px] overflow-y-auto">
            {searchResults.map((location, index) => (
              <div
                key={index}
                className="p-2 hover:bg-gray-700/50 cursor-pointer border-b border-platinum/10 last:border-0"
                onClick={() => onLocationSelect(location.name)}
              >
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-platinum/70" />
                  <div>
                    <p className="text-sm font-medium text-platinum">{location.name}</p>
                    <p className="text-xs text-platinum/70">{location.type}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main content */}
      <div className="flex-1 flex">
        {/* Categories sidebar */}
        <div className="w-48 bg-gray-900/80 border-r border-platinum/20 overflow-hidden flex flex-col">
          <div className="p-3 border-b border-platinum/20 bg-gray-900">
            <h3 className="text-sm font-semibold text-platinum">Categories</h3>
          </div>

          <ScrollArea className="flex-1 h-[calc(500px-56px-56px)]">
            <div className="p-2">
              {/* All Locations option */}
              <div
                className={`p-2 rounded cursor-pointer mb-3 flex items-center ${
                  selectedCategory === "all" ? "bg-gray-800 border-l-2 border-platinum pl-1.5" : "pl-2"
                }`}
                onClick={() => onCategorySelect("all")}
              >
                <div className="w-6 h-6 rounded-full bg-gray-500 flex items-center justify-center mr-2">
                  <Map className="h-3 w-3 text-white" />
                </div>
                <div className="flex-1">
                  <div className="text-xs font-medium text-platinum">All Locations</div>
                  <div className="text-[10px] text-platinum/60">{luxuryLocations.length} locations</div>
                </div>
              </div>

              {/* Category groups */}
              {categoryGroups.map((group) => (
                <div key={group.id} className="mb-2">
                  <div
                    className="p-2 rounded cursor-pointer bg-gray-800/50 flex items-center justify-between"
                    onClick={() => toggleCategoryGroup(group.id)}
                  >
                    <span className="text-xs font-semibold text-platinum">{group.name}</span>
                    {expandedGroups[group.id] ? (
                      <ChevronUp className="h-3 w-3 text-platinum/70" />
                    ) : (
                      <ChevronDown className="h-3 w-3 text-platinum/70" />
                    )}
                  </div>

                  {expandedGroups[group.id] && (
                    <div className="mt-1 ml-2 space-y-1">
                      {/* Show only 5 categories at a time */}
                      {getPaginatedCategories(group.id).map((categoryId) => {
                        const category = categories.find((c) => c.id === categoryId)
                        if (!category) return null

                        const CategoryIcon = getCategoryIcon(category.id)
                        const isActive = selectedCategory === category.id
                        const locationCount = luxuryLocations.filter((loc) => loc.type === category.id).length

                        return (
                          <div
                            key={category.id}
                            className={`p-2 rounded cursor-pointer flex items-center ${
                              isActive ? "bg-gray-800 border-l-2 border-platinum pl-1.5" : "pl-2"
                            }`}
                            onClick={() => onCategorySelect(category.id)}
                          >
                            <div
                              className={`w-5 h-5 rounded-full ${category.color} flex items-center justify-center mr-2`}
                            >
                              <CategoryIcon className="h-2.5 w-2.5 text-white" />
                            </div>
                            <div className="flex-1">
                              <div className="text-xs font-medium text-platinum">{category.name}</div>
                              <div className="text-[10px] text-platinum/60">{locationCount} locations</div>
                            </div>
                          </div>
                        )
                      })}

                      {/* Category pagination controls */}
                      {getCategoryGroupPages(group.id) > 1 && (
                        <div className="flex justify-between items-center mt-2 px-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => prevCategoryPage()}
                            disabled={currentCategoryPage === 1}
                            className="h-6 w-6 p-0 text-platinum/70 hover:text-platinum hover:bg-gray-800"
                          >
                            <ChevronLeft className="h-4 w-4" />
                          </Button>
                          <span className="text-[10px] text-platinum/60">
                            {currentCategoryPage} / {getCategoryGroupPages(group.id)}
                          </span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => nextCategoryPage(group.id)}
                            disabled={currentCategoryPage === getCategoryGroupPages(group.id)}
                            className="h-6 w-6 p-0 text-platinum/70 hover:text-platinum hover:bg-gray-800"
                          >
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Locations list */}
        <div className="flex-1 bg-gray-900/50 flex flex-col">
          <div className="p-3 border-b border-platinum/20 bg-gray-900/80">
            <div className="flex items-center">
              <div className={`w-6 h-6 rounded-full ${currentCategory.color} flex items-center justify-center mr-2`}>
                {React.createElement(getCategoryIcon(currentCategory.id), { className: "h-3 w-3 text-white" })}
              </div>
              <h3 className="text-sm font-semibold text-platinum">{currentCategory.name}</h3>
            </div>
            <p className="text-xs text-platinum/60 mt-1">{filteredLocations.length} locations found</p>
          </div>

          {/* Improved locations list with better use of space */}
          <ScrollArea className="flex-1">
            <div className="p-3">
              {/* Locations grid - now using a more compact list view */}
              <div className="space-y-2">
                {currentLocations.map((location, index) => (
                  <Card
                    key={index}
                    className={`${
                      location.essential
                        ? "bg-gray-800/70 border-l-4 border-l-rose-600 border-y border-r border-platinum/20"
                        : "bg-gray-800/70 border-platinum/20"
                    } hover:bg-gray-800/90 transition-colors`}
                  >
                    <div className="p-3">
                      {/* Location header - always visible */}
                      <div
                        className="flex justify-between items-start cursor-pointer"
                        onClick={() => toggleLocationExpansion(location.name)}
                      >
                        <div className="flex items-start gap-2">
                          <div
                            className={`w-6 h-6 rounded-full ${categories.find((c) => c.id === location.type)?.color || "bg-gray-500"} flex items-center justify-center mt-0.5`}
                          >
                            {React.createElement(getCategoryIcon(location.type), { className: "h-3 w-3 text-white" })}
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-platinum">{location.name}</h4>
                            <div className="flex items-center gap-2 mt-0.5">
                              <Badge
                                variant="outline"
                                className={`text-[10px] border-platinum/30 ${
                                  location.essential ? "text-rose-400" : "text-platinum/70"
                                }`}
                              >
                                {location.type}
                              </Badge>
                              {location.priceRange && (
                                <span className="text-[10px] text-platinum/70">{location.priceRange}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {location.rating && renderRatingStars(location.rating)}
                          {expandedLocation === location.name ? (
                            <ChevronUp className="h-4 w-4 text-platinum/70 ml-2" />
                          ) : (
                            <ChevronDown className="h-4 w-4 text-platinum/70 ml-2" />
                          )}
                        </div>
                      </div>

                      {/* Expanded content - only visible when expanded */}
                      {expandedLocation === location.name && (
                        <div className="mt-3 pt-3 border-t border-platinum/10">
                          <p className="text-xs text-platinum/80 mb-3">{location.description}</p>

                          {location.amenities && location.amenities.length > 0 && (
                            <div className="mb-3">
                              <h5 className="text-xs font-medium text-platinum/70 mb-1">Amenities</h5>
                              <div className="flex flex-wrap gap-1">
                                {location.amenities.map((amenity, i) => (
                                  <Badge key={i} variant="secondary" className="text-[9px] bg-gray-700/70">
                                    {amenity}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          <div className="flex flex-wrap gap-4 text-xs">
                            {location.phone && (
                              <div className="flex items-center">
                                <Phone className="h-3 w-3 mr-1 text-platinum/60" />
                                <span className="text-platinum/80">{location.phone}</span>
                              </div>
                            )}

                            {location.website && (
                              <a
                                href={location.website}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center text-platinum hover:text-platinum/100 transition-colors"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <Globe className="h-3 w-3 mr-1 text-platinum/60" />
                                Visit Website
                              </a>
                            )}

                            <Button
                              size="sm"
                              variant="outline"
                              className="h-6 px-2 text-xs bg-platinum/10 hover:bg-platinum/20 border-platinum/30 text-platinum"
                              onClick={(e) => {
                                e.stopPropagation()
                                onLocationSelect(location.name)
                              }}
                            >
                              <MapPin className="h-3 w-3 mr-1" />
                              View on Map
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  </Card>
                ))}

                {filteredLocations.length === 0 && (
                  <div className="p-4 text-center text-platinum/60 text-sm bg-gray-800/50 rounded-lg border border-platinum/10">
                    <Info className="h-5 w-5 mx-auto mb-2 text-platinum/40" />
                    No locations found in this category
                  </div>
                )}
              </div>
            </div>
          </ScrollArea>

          {/* Pagination controls */}
          {filteredLocations.length > locationsPerPage && (
            <div className="flex justify-center items-center p-3 border-t border-platinum/20 bg-gray-900/50">
              <Button
                variant="outline"
                size="sm"
                onClick={prevPage}
                disabled={currentPage === 1}
                className="h-8 px-2 bg-gray-800/50 border-platinum/30 text-platinum hover:bg-gray-700"
              >
                Previous
              </Button>
              <div className="mx-4 text-xs text-platinum/80">
                Page {currentPage} of {totalPages}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={nextPage}
                disabled={currentPage === totalPages}
                className="h-8 px-2 bg-gray-800/50 border-platinum/30 text-platinum hover:bg-gray-700"
              >
                Next
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
