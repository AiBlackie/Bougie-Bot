import { Avatar } from "@/components/ui/avatar"
import { Bot } from "lucide-react"

export function BotAvatar() {
  return (
    <Avatar className="bg-gradient-to-br from-platinum to-platinum/70 p-1">
      <div className="h-full w-full rounded-full bg-black flex items-center justify-center">
        <Bot className="h-5 w-5 text-platinum" />
      </div>
    </Avatar>
  )
}
