"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import {
  Sun,
  Cloud,
  CloudRain,
  CloudLightning,
  CloudSun,
  CloudFog,
  CloudDrizzle,
  CloudSnow,
  Clock,
  Loader2,
  Wind,
  Droplets,
  RefreshCw,
} from "lucide-react"
import { Button } from "@/components/ui/button"

// Enhanced weather icon mapping
const weatherIcons = {
  "01d": Sun, // clear sky day
  "01n": Sun, // clear sky night
  "02d": CloudSun, // few clouds day
  "02n": CloudSun, // few clouds night
  "03d": Cloud, // scattered clouds day
  "03n": Cloud, // scattered clouds night
  "04d": Cloud, // broken clouds day
  "04n": Cloud, // broken clouds night
  "09d": CloudDrizzle, // shower rain day
  "09n": CloudDrizzle, // shower rain night
  "10d": CloudRain, // rain day
  "10n": CloudRain, // rain night
  "11d": CloudLightning, // thunderstorm day
  "11n": CloudLightning, // thunderstorm night
  "13d": CloudSnow, // snow day
  "13n": CloudSnow, // snow night
  "50d": CloudFog, // mist day
  "50n": CloudFog, // mist night
}

// Barbados coordinates
const BARBADOS_LAT = 13.1939
const BARBADOS_LON = -59.5432

export function WeatherTimeDisplay() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [weather, setWeather] = useState<{
    temp: number | null
    description: string
    icon: string
    humidity?: number
    windSpeed?: number
    loading: boolean
    error: boolean
    isEstimate: boolean
    lastUpdated?: string
  }>({
    temp: null,
    description: "Loading...",
    icon: "01d",
    loading: true,
    error: false,
    isEstimate: false,
  })
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Fetch weather data
  const fetchWeather = async () => {
    try {
      setIsRefreshing(true)

      // Using our API route that now only returns simulated data
      const response = await fetch("/api/weather", {
        // Add cache control to avoid stale data
        cache: "no-cache",
        next: { revalidate: 0 },
      })

      if (!response.ok) {
        throw new Error(`Weather API error: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      setWeather({
        temp: data.temp,
        description: data.description,
        icon: data.icon,
        humidity: data.humidity,
        windSpeed: data.windSpeed,
        loading: false,
        error: false,
        isEstimate: true, // Always true since we're using simulated data
        lastUpdated: data.lastUpdated || new Date().toISOString(),
      })
    } catch (error) {
      console.error("Error fetching weather:", error)
      // Fallback data if even our API route fails
      setWeather({
        temp: 28,
        description: "Sunny",
        icon: "01d",
        humidity: 75,
        windSpeed: 5.0,
        loading: false,
        error: true,
        isEstimate: true,
        lastUpdated: new Date().toISOString(),
      })
    } finally {
      setIsRefreshing(false)
    }
  }

  // Initial fetch and refresh interval
  useEffect(() => {
    fetchWeather()

    // Refresh weather every 30 minutes
    const weatherInterval = setInterval(fetchWeather, 30 * 60 * 1000)

    return () => clearInterval(weatherInterval)
  }, [])

  // Update time every minute
  useEffect(() => {
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000)

    return () => clearInterval(timeInterval)
  }, [])

  // Format time for Barbados (UTC-4)
  const formatBarbadosTime = (date: Date) => {
    // Create a new date object using the current time
    const now = new Date()

    // Get the UTC time in milliseconds
    const utcTime = now.getTime() + now.getTimezoneOffset() * 60000

    // Barbados is UTC-4, so we subtract 4 hours (4 * 60 * 60 * 1000 milliseconds)
    const barbadosTime = new Date(utcTime - 4 * 60 * 60 * 1000)

    // Format the time
    return barbadosTime.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  // Format the last updated time
  const formatLastUpdated = (isoString?: string) => {
    if (!isoString) return "Unknown"

    const date = new Date(isoString)
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  // Get the appropriate weather icon component
  const WeatherIcon = weather.loading ? Loader2 : weatherIcons[weather.icon as keyof typeof weatherIcons] || Sun

  return (
    <Card className="bg-gray-900/70 border-platinum/30 p-3 text-platinum">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4" />
          <span className="text-sm">{formatBarbadosTime(currentTime)}</span>
          <span className="text-xs text-platinum/70">Barbados Time</span>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <WeatherIcon className={`h-5 w-5 text-platinum ${weather.loading ? "animate-spin" : ""}`} />
            {weather.temp !== null ? (
              <div className="flex flex-col">
                <span className="text-sm font-medium">{weather.temp}°C</span>
                <span className="text-xs text-platinum/70 capitalize">{weather.description}</span>
              </div>
            ) : (
              <span className="text-sm">Loading weather...</span>
            )}
          </div>

          {!weather.loading && !weather.error && (
            <div className="flex items-center gap-3 border-l border-platinum/20 pl-3">
              {weather.humidity && (
                <div className="flex items-center gap-1" title="Humidity">
                  <Droplets className="h-3 w-3 text-platinum/70" />
                  <span className="text-xs">{weather.humidity}%</span>
                </div>
              )}

              {weather.windSpeed && (
                <div className="flex items-center gap-1" title="Wind Speed">
                  <Wind className="h-3 w-3 text-platinum/70" />
                  <span className="text-xs">{weather.windSpeed} m/s</span>
                </div>
              )}
            </div>
          )}

          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 text-platinum/70 hover:text-platinum hover:bg-gray-800/50"
            onClick={fetchWeather}
            disabled={isRefreshing}
            title="Refresh weather data"
          >
            <RefreshCw className={`h-3 w-3 ${isRefreshing ? "animate-spin" : ""}`} />
            <span className="sr-only">Refresh</span>
          </Button>
        </div>
      </div>

      {weather.isEstimate && (
        <div className="mt-1 flex justify-end">
          <div className="flex items-center gap-1">
            <span className="text-xs text-amber-400/80 italic">
              Simulated weather data
              {weather.lastUpdated && ` (Updated: ${formatLastUpdated(weather.lastUpdated)})`}
            </span>
          </div>
        </div>
      )}
    </Card>
  )
}
