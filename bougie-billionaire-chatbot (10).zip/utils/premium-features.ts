// Types of premium features
export type PremiumFeatureType =
  | "custom_itinerary"
  | "vip_concierge"
  | "priority_support"
  | "exclusive_access"
  | "personalized_recommendations"
  | "multilingual"

// Premium feature definitions with required subscription level
export const premiumFeatures: Record<
  PremiumFeatureType,
  {
    tier: "basic" | "premium"
    keywords: string[]
    description: string
    previewAvailable: boolean
    previewLimit?: string
  }
> = {
  custom_itinerary: {
    tier: "premium",
    keywords: [
      "create itinerary",
      "plan my trip",
      "custom itinerary",
      "day by day plan",
      "travel plan",
      "schedule for my trip",
      "plan my vacation",
      "itinerary for",
    ],
    description: "Custom itinerary planning with day-by-day schedules tailored to your preferences",
    previewAvailable: true,
    previewLimit: "1-day sample itinerary",
  },
  vip_concierge: {
    tier: "premium",
    keywords: [
      "vip",
      "exclusive access",
      "private event",
      "celebrity",
      "arrange meeting",
      "special request",
      "concierge service",
      "personal assistant",
    ],
    description: "VIP concierge services including exclusive access and special arrangements",
    previewAvailable: false,
  },
  priority_support: {
    tier: "premium",
    keywords: [
      "24/7",
      "emergency",
      "urgent",
      "immediate",
      "priority support",
      "right away",
      "as soon as possible",
      "need help now",
    ],
    description: "24/7 priority support for urgent requests and immediate assistance",
    previewAvailable: false,
  },
  exclusive_access: {
    tier: "premium",
    keywords: [
      "exclusive",
      "members only",
      "private access",
      "not open to public",
      "restricted",
      "invitation only",
      "special permission",
      "limited availability",
    ],
    description: "Information and bookings for exclusive, members-only venues and events",
    previewAvailable: true,
    previewLimit: "Basic information only",
  },
  personalized_recommendations: {
    tier: "basic",
    keywords: [
      "personalized",
      "tailored",
      "specifically for me",
      "based on my preferences",
      "customized",
      "just for me",
      "personal recommendation",
      "suited to my taste",
    ],
    description: "Personalized recommendations based on your preferences and travel style",
    previewAvailable: true,
    previewLimit: "Limited to 2 recommendations",
  },
  multilingual: {
    tier: "basic",
    keywords: [
      "french",
      "spanish",
      "german",
      "portuguese",
      "italian",
      "chinese",
      "japanese",
      "arabic",
      "translate",
      "language",
    ],
    description: "Multilingual support in up to 9 languages",
    previewAvailable: false,
  },
}

// Function to detect premium features in a message
export function detectPremiumFeatures(message: string): PremiumFeatureType[] {
  const lowercaseMessage = message.toLowerCase()
  const detectedFeatures: PremiumFeatureType[] = []

  Object.entries(premiumFeatures).forEach(([featureType, feature]) => {
    const matchesKeyword = feature.keywords.some((keyword) => lowercaseMessage.includes(keyword.toLowerCase()))

    if (matchesKeyword) {
      detectedFeatures.push(featureType as PremiumFeatureType)
    }
  })

  return detectedFeatures
}

// Check if user has access to a premium feature
export function hasFeatureAccess(featureType: PremiumFeatureType, subscription: { tier: string }): boolean {
  const feature = premiumFeatures[featureType]

  // If feature requires premium tier
  if (feature.tier === "premium") {
    return subscription.tier === "premium"
  }

  // If feature requires at least basic tier
  if (feature.tier === "basic") {
    return subscription.tier === "basic" || subscription.tier === "premium"
  }

  return false
}

// Generate a preview response for a premium feature
export function generateFeaturePreview(featureType: PremiumFeatureType): string {
  const feature = premiumFeatures[featureType]

  if (!feature.previewAvailable) {
    return `I apologize, but ${feature.description} is a premium feature available only to ${feature.tier === "premium" ? "Global Luxury" : "Language Plus"} subscribers. Would you like to learn more about our subscription options?`
  }

  let previewResponse = ""

  switch (featureType) {
    case "custom_itinerary":
      previewResponse = `I'd be happy to provide a sample 1-day itinerary preview. For a full custom itinerary with day-by-day planning, you'll need to upgrade to our Global Luxury plan.\n\n**Sample Day in Barbados:**\n\n**Morning:** Begin with breakfast at Café Luna in Christ Church, offering stunning ocean views and excellent cuisine.\n\n**Midday:** Explore Harrison's Cave with a guided tram tour through this crystallized limestone cavern.\n\n**Afternoon:** Enjoy a lunch at The Tides Restaurant in Holetown, followed by swimming and relaxation at Paynes Bay Beach.\n\n**Evening:** Experience a sunset catamaran cruise along the west coast with cocktails and appetizers.\n\n**Night:** Dinner at Champers Restaurant with its oceanfront setting and excellent seafood.\n\nFor a complete personalized itinerary covering your entire stay, consider upgrading to our Global Luxury plan. Would you like to learn more?`
      break

    case "exclusive_access":
      previewResponse = `I can provide some basic information about exclusive venues in Barbados. The Sandy Lane Owner's Club is one of the most prestigious members-only clubs, offering exceptional amenities and privacy. For detailed information about membership, access, and booking exclusive experiences, you would need our Global Luxury plan.\n\nWould you like to learn more about upgrading to access this premium feature?`
      break

    case "personalized_recommendations":
      previewResponse = `Here are two personalized recommendations based on luxury preferences:\n\n1. **The Cliff Restaurant** - One of the most renowned dining establishments in Barbados with stunning sea views and exceptional cuisine.\n\n2. **Sandy Lane Hotel** - The pinnacle of luxury accommodation in Barbados with world-class amenities and service.\n\nFor more comprehensive personalized recommendations tailored to your specific preferences, consider upgrading to our Language Plus plan. Would you like to learn more?`
      break

    default:
      previewResponse = `I can provide a limited preview of this premium feature. For full access, you'll need to upgrade to our ${feature.tier === "premium" ? "Global Luxury" : "Language Plus"} plan. Would you like to learn more about our subscription options?`
  }

  return previewResponse
}
